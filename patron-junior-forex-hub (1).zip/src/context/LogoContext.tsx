import React, { createContext, useContext, useState, useEffect } from 'react';

export interface LogoConfig {
  logoUrl: string | null;
  logoType: 'custom' | 'default-emblem' | 'candlestick-shield' | 'bull-sniper';
  customName: string;
}

interface LogoContextType {
  logoUrl: string | null;
  logoType: LogoConfig['logoType'];
  customName: string;
  setCustomLogo: (url: string) => void;
  setPresetLogo: (type: LogoConfig['logoType']) => void;
  setCustomName: (name: string) => void;
  resetToDefault: () => void;
  isCustomUploaded: boolean;
}

const STORAGE_KEY = 'patron_junior_forex_logo';

const LogoContext = createContext<LogoContextType | undefined>(undefined);

export const LogoProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [logoUrl, setLogoUrl] = useState<string | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.logoUrl || null;
      }
    } catch {
      // ignore
    }
    return null;
  });

  const [logoType, setLogoType] = useState<LogoConfig['logoType']>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.logoType || 'bull-sniper';
      }
    } catch {
      // ignore
    }
    return 'bull-sniper';
  });

  const [customName, setCustomNameState] = useState<string>('Patron Junior Forex Hub');

  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          logoUrl,
          logoType,
          customName,
        })
      );
    } catch (e) {
      console.warn('Could not save logo to localStorage', e);
    }
  }, [logoUrl, logoType, customName]);

  const setCustomLogo = (url: string) => {
    setLogoUrl(url);
    setLogoType('custom');
  };

  const setPresetLogo = (type: LogoConfig['logoType']) => {
    setLogoType(type);
    if (type !== 'custom') {
      setLogoUrl(null);
    }
  };

  const setCustomName = (name: string) => {
    setCustomNameState(name);
  };

  const resetToDefault = () => {
    setLogoUrl(null);
    setLogoType('bull-sniper');
    localStorage.removeItem(STORAGE_KEY);
  };

  return (
    <LogoContext.Provider
      value={{
        logoUrl,
        logoType,
        customName,
        setCustomLogo,
        setPresetLogo,
        setCustomName,
        resetToDefault,
        isCustomUploaded: !!logoUrl && logoType === 'custom',
      }}
    >
      {children}
    </LogoContext.Provider>
  );
};

export const useLogo = () => {
  const context = useContext(LogoContext);
  if (!context) {
    throw new Error('useLogo must be used within a LogoProvider');
  }
  return context;
};
