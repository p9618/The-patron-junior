import React, { useState, useRef } from 'react';
import { useLogo } from '../context/LogoContext';
import { Upload, X, Check, Image as ImageIcon, RotateCcw, Shield, Sparkles } from 'lucide-react';

interface LogoUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LogoUploadModal: React.FC<LogoUploadModalProps> = ({ isOpen, onClose }) => {
  const { logoUrl, logoType, setCustomLogo, setPresetLogo, resetToDefault } = useLogo();
  const [urlInput, setUrlInput] = useState('');
  const [previewUrl, setPreviewUrl] = useState<string | null>(logoUrl);
  const [selectedPreset, setSelectedPreset] = useState(logoType);
  const [uploadSuccessMessage, setUploadSuccessMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('File size exceeds 5MB limit. Please choose a smaller logo.');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        setPreviewUrl(result);
        setSelectedPreset('custom');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleApply = () => {
    if (selectedPreset === 'custom') {
      const target = previewUrl || (urlInput.trim() ? urlInput.trim() : null);
      if (target) {
        setCustomLogo(target);
        setUploadSuccessMessage('Custom logo applied successfully across Patron Junior Forex Hub!');
      }
    } else {
      setPresetLogo(selectedPreset);
      setUploadSuccessMessage('Preset emblem applied successfully!');
    }
    setTimeout(() => {
      setUploadSuccessMessage(null);
      onClose();
    }, 1200);
  };

  const handleReset = () => {
    resetToDefault();
    setPreviewUrl(null);
    setSelectedPreset('bull-sniper');
    setUrlInput('');
    setUploadSuccessMessage('Restored to default Patron Junior emblem.');
    setTimeout(() => {
      setUploadSuccessMessage(null);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-[#0B1530] border border-[#1E3A8A] rounded-2xl shadow-2xl overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#1E3A8A]/60 bg-[#070E22]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#1E3A8A]/50 border border-[#FACC15]/40 flex items-center justify-center text-[#FACC15]">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-display">Provide Your Hub Logo</h3>
              <p className="text-xs text-slate-400">Upload your personal logo or choose an emblem</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {uploadSuccessMessage && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-xl flex items-center gap-2 text-emerald-300 text-xs font-medium">
              <Check className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{uploadSuccessMessage}</span>
            </div>
          )}

          {/* Option A: File Upload */}
          <div className="space-y-3">
            <label className="block text-xs font-bold uppercase tracking-wider text-[#FACC15]">
              Option 1: Upload Your Logo File (PNG, SVG, JPG)
            </label>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="image/png,image/jpeg,image/svg+xml,image/webp"
              className="hidden"
            />
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-[#1E3A8A] hover:border-[#FACC15] rounded-xl p-6 text-center cursor-pointer transition-colors bg-[#081026]/70 group"
            >
              <div className="w-12 h-12 mx-auto rounded-full bg-[#13234F] text-[#FACC15] group-hover:scale-110 transition-transform flex items-center justify-center mb-2">
                <ImageIcon className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-white">Click or tap to upload your logo</p>
              <p className="text-xs text-slate-400 mt-1">Recommended: Transparent PNG or SVG (Max 5MB)</p>
            </div>
          </div>

          {/* Option B: Direct URL */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
              Option 2: Paste Direct Image URL
            </label>
            <div className="flex gap-2">
              <input
                type="url"
                placeholder="https://yourdomain.com/logo.png"
                value={urlInput}
                onChange={(e) => {
                  setUrlInput(e.target.value);
                  if (e.target.value) {
                    setPreviewUrl(e.target.value);
                    setSelectedPreset('custom');
                  }
                }}
                className="flex-1 bg-[#060D20] border border-[#1E3A8A] rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#FACC15]"
              />
              <button
                type="button"
                onClick={() => {
                  if (urlInput.trim()) {
                    setPreviewUrl(urlInput.trim());
                    setSelectedPreset('custom');
                  }
                }}
                className="px-3 py-2 bg-[#1E3A8A] hover:bg-[#2563EB] text-white text-xs font-semibold rounded-lg transition-colors whitespace-nowrap"
              >
                Preview URL
              </button>
            </div>
          </div>

          {/* Option C: Bespoke Preset Emblems */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
              Option 3: Or Choose a Crafted Theme Emblem
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  setSelectedPreset('bull-sniper');
                  setPreviewUrl(null);
                }}
                className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all ${
                  selectedPreset === 'bull-sniper'
                    ? 'border-[#FACC15] bg-[#1E3A8A]/30 ring-1 ring-[#FACC15]'
                    : 'border-[#1E3A8A]/40 bg-[#081026] hover:border-slate-500'
                }`}
              >
                <div className="w-9 h-9 rounded-lg bg-[#0A1633] border border-[#1D4ED8] flex items-center justify-center shrink-0">
                  <Shield className="w-5 h-5 text-[#FACC15]" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Blue Bull Sniper</div>
                  <div className="text-[10px] text-slate-400">Blue, Gold & Red Crest</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectedPreset('candlestick-shield');
                  setPreviewUrl(null);
                }}
                className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all ${
                  selectedPreset === 'candlestick-shield'
                    ? 'border-[#FACC15] bg-[#1E3A8A]/30 ring-1 ring-[#FACC15]'
                    : 'border-[#1E3A8A]/40 bg-[#081026] hover:border-slate-500'
                }`}
              >
                <div className="w-9 h-9 rounded-lg bg-[#0A1633] border border-[#EF4444] flex items-center justify-center shrink-0">
                  <Sparkles className="w-5 h-5 text-[#EF4444]" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Candlestick Shield</div>
                  <div className="text-[10px] text-slate-400">Price Action Breakout</div>
                </div>
              </button>
            </div>
          </div>

          {/* Real-time Theme Test Palette (Blue, Yellow, White, Red) */}
          <div className="space-y-2 pt-2 border-t border-[#1E3A8A]/40">
            <span className="text-xs font-semibold text-slate-400">
              Live Preview across your Theme Colors:
            </span>
            <div className="grid grid-cols-4 gap-2">
              {/* Blue surface */}
              <div className="p-3 bg-[#070E22] border border-[#1E3A8A] rounded-lg text-center flex flex-col items-center justify-center min-h-[70px]">
                <span className="text-[9px] uppercase tracking-wider text-slate-400 mb-1">Navy Blue</span>
                {previewUrl && selectedPreset === 'custom' ? (
                  <img src={previewUrl} alt="Logo" className="w-8 h-8 object-contain" />
                ) : (
                  <Shield className="w-6 h-6 text-[#FACC15]" />
                )}
              </div>
              {/* Yellow surface */}
              <div className="p-3 bg-[#FACC15] rounded-lg text-center flex flex-col items-center justify-center min-h-[70px]">
                <span className="text-[9px] uppercase tracking-wider text-slate-900 font-bold mb-1">Gold Yellow</span>
                {previewUrl && selectedPreset === 'custom' ? (
                  <img src={previewUrl} alt="Logo" className="w-8 h-8 object-contain" />
                ) : (
                  <Shield className="w-6 h-6 text-[#0A1633]" />
                )}
              </div>
              {/* White surface */}
              <div className="p-3 bg-white rounded-lg text-center flex flex-col items-center justify-center min-h-[70px]">
                <span className="text-[9px] uppercase tracking-wider text-slate-800 font-bold mb-1">Crisp White</span>
                {previewUrl && selectedPreset === 'custom' ? (
                  <img src={previewUrl} alt="Logo" className="w-8 h-8 object-contain" />
                ) : (
                  <Shield className="w-6 h-6 text-[#1E3A8A]" />
                )}
              </div>
              {/* Red surface */}
              <div className="p-3 bg-[#DC2626] rounded-lg text-center flex flex-col items-center justify-center min-h-[70px]">
                <span className="text-[9px] uppercase tracking-wider text-white font-bold mb-1">Crimson Red</span>
                {previewUrl && selectedPreset === 'custom' ? (
                  <img src={previewUrl} alt="Logo" className="w-8 h-8 object-contain" />
                ) : (
                  <Shield className="w-6 h-6 text-white" />
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-[#070E22] border-t border-[#1E3A8A]/60 flex items-center justify-between">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Default</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleApply}
              className="px-5 py-2 text-xs font-bold text-slate-950 bg-[#FACC15] hover:bg-[#EAB308] rounded-lg transition-colors shadow-md flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply Logo</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
