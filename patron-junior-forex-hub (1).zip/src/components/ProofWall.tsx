import React from 'react';
import { STUDENT_PROOF } from '../data/mockData';
import { CheckCircle2, Trophy } from 'lucide-react';

export const ProofWall: React.FC = () => {
  return (
    <section id="payouts" className="py-16 bg-[#070E22] border-b border-[#1E3A8A]/40 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center space-y-2 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0A1633] border border-[#FACC15]/50 text-xs font-mono font-bold text-[#FACC15]">
            <Trophy className="w-3.5 h-3.5" />
            <span>TRADE TO WITHDRAW ALWAYS</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
            Verified Student Funded Payouts
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            Real prop firm payouts earned by Patron Junior Forex Hub students.
          </p>
        </div>

        {/* 4 Clean Student Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {STUDENT_PROOF.map((s) => (
            <div
              key={s.id}
              className="p-5 rounded-2xl bg-[#0A1633] border border-[#1E3A8A] hover:border-[#FACC15]/50 transition-all flex flex-col justify-between space-y-3"
            >
              <div className="flex items-center justify-between pb-3 border-b border-[#1E3A8A]/50">
                <div>
                  <h4 className="text-base font-bold text-white font-display">{s.name}</h4>
                  <span className="text-xs text-slate-400">{s.location} · {s.propFirm}</span>
                </div>
                <strong className="text-lg font-black text-emerald-400 font-mono">
                  {s.payoutAmount}
                </strong>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 italic leading-relaxed">
                "{s.quote}"
              </p>

              <div className="pt-2 border-t border-[#1E3A8A]/40 flex items-center justify-between text-xs font-mono text-slate-400">
                <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{s.verifiedBadge}</span>
                </div>
                <span>{s.date}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
