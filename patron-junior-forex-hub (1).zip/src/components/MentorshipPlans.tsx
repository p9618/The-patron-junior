import React from 'react';
import { MENTORSHIP_TIERS } from '../data/mockData';
import { Check, Star, ArrowRight } from 'lucide-react';

interface MentorshipPlansProps {
  onSelectTier: (tierId: string) => void;
}

export const MentorshipPlans: React.FC<MentorshipPlansProps> = ({ onSelectTier }) => {
  return (
    <section id="mentorship" className="py-16 bg-[#060D20] border-b border-[#1E3A8A]/40 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center space-y-2 mb-12">
          <span className="text-xs font-mono font-bold text-[#FACC15] uppercase tracking-wider">
            Memberships & Programs
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
            Accelerate Your Trading Journey
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            From daily sniper trade signals to complete 1-on-1 mentorship to pass prop challenges.
          </p>
        </div>

        {/* 3 Simple Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
          {MENTORSHIP_TIERS.map((tier) => {
            const isPopular = tier.popular;
            return (
              <div
                key={tier.id}
                className={`rounded-2xl p-6 flex flex-col justify-between transition-all ${
                  isPopular
                    ? 'bg-[#0B1838] border-2 border-[#FACC15] shadow-xl md:-translate-y-1'
                    : 'bg-[#0A1633] border border-[#1E3A8A]'
                }`}
              >
                <div>
                  {/* Top */}
                  <div className="pb-4 border-b border-[#1E3A8A]/60 space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-bold text-white font-display">{tier.name}</h3>
                      {isPopular && (
                        <span className="px-2 py-0.5 rounded bg-[#FACC15] text-slate-950 text-[10px] font-black uppercase tracking-wider">
                          Popular
                        </span>
                      )}
                    </div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl sm:text-4xl font-black text-white font-mono tabular-nums">
                        {tier.price}
                      </span>
                      <span className="text-xs text-slate-400 font-sans">/{tier.billingPeriod}</span>
                    </div>
                  </div>

                  {/* Features */}
                  <ul className="py-5 space-y-2.5 text-xs text-slate-200">
                    {tier.features.slice(0, 5).map((f, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-[#FACC15] shrink-0 mt-0.5" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action */}
                <button
                  type="button"
                  onClick={() => onSelectTier(tier.id)}
                  className={`w-full py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    isPopular
                      ? 'bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 shadow-md'
                      : 'bg-[#1E3A8A] hover:bg-[#2563EB] text-white'
                  }`}
                >
                  <span>{tier.ctaText}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
