import React, { useState } from 'react';
import { RECENT_SIGNALS } from '../data/mockData';
import { TradeSignal } from '../types';
import { Copy, Check, TrendingUp, Send, Sparkles, Activity, ShieldCheck, Flame } from 'lucide-react';
import { CurrencyStrengthMeter, AIDirectionResult } from './CurrencyStrengthMeter';

interface SignalTerminalProps {
  onJoinVIP: () => void;
}

export const SignalTerminal: React.FC<SignalTerminalProps> = ({ onJoinVIP }) => {
  const [filter, setFilter] = useState<'all' | 'gold' | 'indices' | 'fx'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [liveAISignals, setLiveAISignals] = useState<TradeSignal[]>([]);

  // When AI generates a fresh signal from the strength meter, we can prepend it to the journal
  const handleAIGeneratedSignal = (aiSig: AIDirectionResult) => {
    const isGold = aiSig.pair.includes('XAU');
    const isIndices = aiSig.pair.includes('NAS') || aiSig.pair.includes('US30') || aiSig.pair.includes('SPX');
    
    const newSignal: TradeSignal = {
      id: `ai-${Date.now()}`,
      pair: aiSig.pair,
      type: (aiSig.direction.includes('BUY') ? 'BUY' : 'SELL') as 'BUY' | 'SELL',
      entry: aiSig.entry,
      stopLoss: aiSig.stopLoss,
      tp1: aiSig.tp1,
      tp2: aiSig.tp2,
      tp3: aiSig.tp3,
      status: 'ACTIVE',
      pipsGained: 0,
      riskReward: aiSig.riskReward,
      timeframe: '15M / 1H',
      date: 'Live AI Analysis',
      setupRationale: `${aiSig.strengthAlignment} ${aiSig.confluence}`,
      category: isGold ? 'gold' : isIndices ? 'indices' : 'fx',
    };

    setLiveAISignals((prev) => [newSignal, ...prev.filter((s) => s.pair !== aiSig.pair)]);
  };

  const allSignals = [...liveAISignals, ...RECENT_SIGNALS];
  const filteredSignals = allSignals.filter((s) => {
    if (filter === 'all') return true;
    return s.category === filter;
  });

  const handleCopy = (sig: TradeSignal) => {
    const text = `PATRON JUNIOR FOREX HUB
Pair: ${sig.pair}
Type: ${sig.type}
Entry: ${sig.entry}
SL: ${sig.stopLoss}
TP1: ${sig.tp1} | TP2: ${sig.tp2} | TP3: ${sig.tp3}
Risk:Reward: ${sig.riskReward}
Trade to Withdraw Always!
WhatsApp: +254740076628 | Telegram: t.me/THEPATRONJUNIOURFOREXHUB`;

    navigator.clipboard.writeText(text);
    setCopiedId(sig.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <section id="signals" className="py-16 bg-[#060D20] border-b border-[#1E3A8A]/40 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* 1. Live Currency Strength Meter & AI Direction Component */}
        <CurrencyStrengthMeter onSignalGenerated={handleAIGeneratedSignal} />

        {/* 2. Journal Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8 pt-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-[#FACC15] uppercase tracking-wider">
                Live Signal Journal
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                STRENGTH-METER BACKED
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display mt-1">
              Latest High-Probability Signals
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              Clear institutional entries with defined stop losses, take profits, and AI market direction.
            </p>
          </div>

          {/* Simple Category Tabs */}
          <div className="flex items-center gap-1 p-1 bg-[#0A1633] border border-[#1E3A8A] rounded-xl self-start sm:self-auto">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                filter === 'all' ? 'bg-[#FACC15] text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('gold')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                filter === 'gold' ? 'bg-[#FACC15] text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
              Gold (XAU)
            </button>
            <button
              onClick={() => setFilter('indices')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                filter === 'indices' ? 'bg-[#FACC15] text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
              Indices
            </button>
            <button
              onClick={() => setFilter('fx')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                filter === 'fx' ? 'bg-[#FACC15] text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
              Forex
            </button>
          </div>
        </div>

        {/* Clean Signal Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredSignals.map((sig) => {
            const isBuy = sig.type.includes('BUY');
            const isLiveAI = sig.id.startsWith('ai-');

            return (
              <div
                key={sig.id}
                className={`bg-[#0A1633] border rounded-2xl p-5 transition-all shadow-md flex flex-col justify-between space-y-4 ${
                  isLiveAI
                    ? 'border-[#FACC15] ring-1 ring-[#FACC15]/40 bg-[#0C1A3D]'
                    : 'border-[#1E3A8A] hover:border-[#FACC15]/60'
                }`}
              >
                {/* Card Top */}
                <div className="flex items-center justify-between pb-3 border-b border-[#1E3A8A]/50">
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-white font-mono">{sig.pair}</span>
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded font-mono ${
                        isBuy
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                          : 'bg-red-950 text-[#EF4444] border border-[#EF4444]/40'
                      }`}
                    >
                      {sig.type}
                    </span>
                    {isLiveAI && (
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#FACC15]/20 text-[#FACC15] border border-[#FACC15]/30 font-bold flex items-center gap-1">
                        <Sparkles className="w-2.5 h-2.5" /> AI LIVE
                      </span>
                    )}
                  </div>
                  <span className="text-xs font-bold text-[#FACC15] font-mono">R:R {sig.riskReward}</span>
                </div>

                {/* Levels */}
                <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
                  <div className="p-2 rounded-lg bg-[#070E22] border border-[#1E3A8A]/40">
                    <span className="text-[10px] text-slate-400 block font-sans">Entry</span>
                    <strong className="text-white text-xs">{sig.entry.toLocaleString()}</strong>
                  </div>
                  <div className="p-2 rounded-lg bg-[#070E22] border border-[#EF4444]/50">
                    <span className="text-[10px] text-[#EF4444] block font-sans font-bold">Stop Loss</span>
                    <strong className="text-[#EF4444] text-xs">{sig.stopLoss.toLocaleString()}</strong>
                  </div>
                  <div className="p-2 rounded-lg bg-[#070E22] border border-[#FACC15]/50">
                    <span className="text-[10px] text-[#FACC15] block font-sans font-bold">Target</span>
                    <strong className="text-[#FACC15] text-xs">{sig.tp2.toLocaleString()}</strong>
                  </div>
                </div>

                {/* Setup note */}
                <p className="text-xs text-slate-300 leading-relaxed bg-[#070E22]/60 p-2.5 rounded-xl border border-[#1E3A8A]/30">
                  {sig.setupRationale}
                </p>

                {/* Bottom Action */}
                <div className="pt-2 border-t border-[#1E3A8A]/40 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold font-mono">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>{sig.pipsGained > 0 ? `+${sig.pipsGained} Pips` : 'Active Setup'}</span>
                  </div>

                  <button
                    onClick={() => handleCopy(sig)}
                    className="py-1.5 px-3 rounded-lg bg-[#0F224D] hover:bg-[#1A387E] border border-[#1E3A8A] text-xs font-semibold text-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedId === sig.id ? (
                      <>
                        <Check className="w-3 h-3 text-[#FACC15]" />
                        <span className="text-[#FACC15]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 text-slate-400" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Clean join CTA */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <a
            href="https://t.me/THEPATRONJUNIOURFOREXHUB"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#0284C7] hover:bg-[#0369A1] text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Join VIP Signals Telegram Channel</span>
          </a>
          <a
            href="https://chat.whatsapp.com/FYzi5id1fLl7kIZUsvl3iO"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#22C55E] hover:bg-[#16A34A] text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all cursor-pointer"
          >
            <span>Join Official WhatsApp Community</span>
          </a>
        </div>
      </div>
    </section>
  );
};
