import React, { useEffect, useRef, useState } from 'react';

export const TickerBar: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [tradingViewLoaded, setTradingViewLoaded] = useState(false);

  useEffect(() => {
    const currentContainer = containerRef.current;
    if (!currentContainer) return;

    // Clear previous contents
    currentContainer.innerHTML = '';

    const widgetDiv = document.createElement('div');
    widgetDiv.className = 'tradingview-widget-container__widget';
    currentContainer.appendChild(widgetDiv);

    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js';
    script.type = 'text/javascript';
    script.async = true;
    script.innerHTML = JSON.stringify({
      symbols: [
        { proName: 'FOREXCOM:XAUUSD', title: 'GOLD' },
        { proName: 'BINANCE:BTCUSDT', title: 'BTCUSDT' },
        { proName: 'FOREXCOM:XAGUSD', title: 'XAGUSD' },
        { proName: 'FOREXCOM:SPX500', title: 'SPX500' },
        { proName: 'FOREXCOM:NAS100', title: 'NAS100' },
        { proName: 'FOREXCOM:DJI', title: 'US30' },
        { proName: 'FX_IDC:EURUSD', title: 'EURUSD' },
        { proName: 'FX_IDC:GBPJPY', title: 'GBPJPY' },
        { proName: 'FX_IDC:GBPUSD', title: 'GBPUSD' },
        { proName: 'FX_IDC:USDJPY', title: 'USDJPY' },
      ],
      showSymbolLogo: true,
      isTransparent: false,
      displayMode: 'adaptive',
      colorTheme: 'light',
      locale: 'en',
    });

    script.onload = () => {
      setTradingViewLoaded(true);
    };

    currentContainer.appendChild(script);

    return () => {
      if (currentContainer) {
        currentContainer.innerHTML = '';
      }
    };
  }, []);

  return (
    <div className="w-full bg-white border-b border-slate-200/90 shadow-xs relative overflow-hidden min-h-[48px]">
      {/* Official Live TradingView Embed Widget */}
      <div className="tradingview-widget-container" ref={containerRef}>
        <div className="tradingview-widget-container__widget"></div>
      </div>

      {/* Fallback while script loads */}
      {!tradingViewLoaded && (
        <div className="absolute inset-0 bg-white flex items-center justify-between px-6 py-2 text-xs font-mono text-slate-700 animate-pulse pointer-events-none">
          <div className="flex items-center gap-6 overflow-hidden">
            <span className="font-bold text-slate-900">GOLD <strong className="text-emerald-600">2,742.96</strong></span>
            <span className="font-bold text-slate-900">BTCUSDT <strong className="text-emerald-600">88,417.92</strong></span>
            <span className="font-bold text-slate-900">XAGUSD <strong className="text-emerald-600">32.86</strong></span>
            <span className="font-bold text-slate-900">SPX500 <strong className="text-emerald-600">5,836.40</strong></span>
            <span className="font-bold text-slate-900">NAS100 <strong className="text-rose-600">20,635.60</strong></span>
            <span className="font-bold text-slate-900">US30 <strong className="text-emerald-600">43,699.50</strong></span>
            <span className="font-bold text-slate-900">EURUSD <strong className="text-emerald-600">1.08450</strong></span>
          </div>
          <span className="text-[10px] text-slate-400 font-sans shrink-0">Loading live TradingView feed...</span>
        </div>
      )}
    </div>
  );
};
