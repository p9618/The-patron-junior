import React from 'react';
import { Target, Clock, ShieldCheck, Users, Award, CheckCircle2 } from 'lucide-react';

export const MentorSection: React.FC = () => {
  return (
    <section id="about" className="py-16 sm:py-24 bg-[#070E22] border-b border-[#1E3A8A]/40 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Split: The Mentor Story */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-20">
          {/* Mentor Photo Container */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border-2 border-[#1E3A8A] bg-[#0A1633] shadow-2xl group">
              <img
                src="/src/assets/images/patron_junior_mentor_1793796457306.jpg"
                alt="Patron Junior - Master Forex Trader and Founder"
                className="w-full h-auto object-cover transition-transform duration-500 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#070E22] via-transparent to-transparent opacity-80" />

              {/* Floating badge */}
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-[#0A1633]/90 backdrop-blur-md border border-[#FACC15]/50 flex items-center justify-between">
                <div>
                  <h4 className="text-base font-bold text-white font-display">Patron Junior</h4>
                  <p className="text-xs text-[#FACC15] font-mono">Founder & Lead Fund Manager</p>
                </div>
                <div className="px-2.5 py-1 rounded bg-[#EF4444] text-white text-[11px] font-bold uppercase tracking-wider">
                  Verified
                </div>
              </div>
            </div>
          </div>

          {/* Mentor Bio & Philosophy */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 text-xs text-slate-400">
              <span className="text-[#FACC15] font-bold uppercase tracking-wider font-mono">
                The Blue Bull Tradition
              </span>
              <span aria-hidden="true">·</span>
              <span>Discipline Over Euphoria</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight leading-tight">
              Built on High Standards. Designed for African and Global Traders.
            </h2>

            <p className="text-base text-slate-300 leading-relaxed">
              Inspired by the energy, institutional mastery, and elite community culture of Blue Bull Forex Hub, Patron Junior founded this academy with one clear mission: to eradicate retail gambling habits and instill Wall Street precision.
            </p>

            <p className="text-sm text-slate-300 leading-relaxed">
              Having managed multi-six-figure proprietary trading funds and mentored over a thousand active traders across Kenya, Nigeria, South Africa, and the UK, Patron Junior teaches the exact algorithmic order flow parameters that banks and market makers operate with.
            </p>

            {/* 4 Pillars Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-[#0A1633] border border-[#1E3A8A]/50 space-y-1.5">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Target className="w-4 h-4 text-[#FACC15]" />
                  <span>Institutional Liquidity</span>
                </div>
                <p className="text-xs text-slate-400">
                  Trade stop-run sweeps and fair value gap taps instead of lagging retail indicators.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#0A1633] border border-[#1E3A8A]/50 space-y-1.5">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Clock className="w-4 h-4 text-[#FACC15]" />
                  <span>Time & Price Precision</span>
                </div>
                <p className="text-xs text-slate-400">
                  Zero sitting in front of charts all day. Execute cleanly at London & New York open.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#0A1633] border border-[#1E3A8A]/50 space-y-1.5">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <ShieldCheck className="w-4 h-4 text-[#EF4444]" />
                  <span>Asymmetric Risk (1:3+ R:R)</span>
                </div>
                <p className="text-xs text-slate-400">
                  Risk 1 unit to capture 3 to 6 units. Maintain profitability even with a 45% win rate.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#0A1633] border border-[#1E3A8A]/50 space-y-1.5">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Award className="w-4 h-4 text-[#FACC15]" />
                  <span>Prop Firm Certification</span>
                </div>
                <p className="text-xs text-slate-400">
                  Comprehensive prep for FTMO, FundedNext, and The5ers 100K/200K evaluation rules.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Split: The Trading Floor & Community Bootcamp */}
        <div className="relative rounded-3xl overflow-hidden border border-[#1E3A8A] bg-[#0A1633] shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
            <div className="lg:col-span-7 relative min-h-[300px] lg:min-h-[420px]">
              <img
                src="/src/assets/images/trading_floor_bootcamp_1793796457434.jpg"
                alt="Patron Junior Forex Hub Trading Floor & Bootcamp"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-[#0A1633] hidden lg:block" />
            </div>

            <div className="lg:col-span-5 p-8 lg:p-10 flex flex-col justify-center space-y-5 bg-[#0A1633]">
              <div className="flex items-center gap-2 text-xs font-mono text-[#FACC15] font-bold">
                <Users className="w-4 h-4" />
                <span>PHYSICAL & DIGITAL TRADING FLOOR</span>
              </div>

              <h3 className="text-2xl font-extrabold text-white font-display">
                Trade in an Elite Environment of Serious Minds
              </h3>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Trading in isolation leads to emotional mistakes and revenge trading. At Patron Junior Forex Hub, students sit side-by-side with fund managers or connect through our live audio-video desks every London and New York session.
              </p>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#FACC15]" />
                  <span>Live London Session Breakdown (7:00 AM - 9:30 AM GMT)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#FACC15]" />
                  <span>New York Opening Bell Sniper Room (1:30 PM - 3:30 PM GMT)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#FACC15]" />
                  <span>Weekly Saturday Student Chart Audits & Psychology Clinic</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
