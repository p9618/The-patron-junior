import React, { useState } from 'react';
import { BrandLogo } from './BrandLogo';
import { ArrowUpRight, Menu, X, PhoneCall } from 'lucide-react';

interface NavbarProps {
  onOpenAppointment: () => void;
  onOpenContact: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAppointment, onOpenContact }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="w-full relative z-40">
      {/* 1. Top Gradient Announcement Bar */}
      <div className="w-full bg-gradient-to-r from-[#0284C7] via-[#EA580C] to-[#E11D48] text-white py-1 px-4 text-center text-xs font-semibold tracking-wide shadow-sm flex flex-wrap items-center justify-center gap-3">
        <span>Trade To Withdraw Always · Mastering Markets</span>
        <span className="hidden sm:inline text-white/50">|</span>
        <div className="flex items-center gap-3 text-[11px]">
          <a
            href="https://chat.whatsapp.com/FYzi5id1fLl7kIZUsvl3iO"
            target="_blank"
            rel="noreferrer"
            className="hover:underline font-bold flex items-center gap-1 text-emerald-100 hover:text-white"
          >
            <span>WhatsApp Community ↗</span>
          </a>
          <span className="text-white/40">·</span>
          <a
            href="https://t.me/THEPATRONJUNIOURFOREXHUB"
            target="_blank"
            rel="noreferrer"
            className="hover:underline font-bold flex items-center gap-1 text-sky-100 hover:text-white"
          >
            <span>Telegram Channel ↗</span>
          </a>
        </div>
      </div>

      {/* 2. Clean White Floating Navigation Bar (Matches screenshot 1) */}
      <header className="bg-white border-b border-slate-200/80 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20 gap-6">
            {/* Logo Lockup */}
            <a href="#" className="flex items-center gap-3 shrink-0">
              <BrandLogo />
            </a>

            {/* Navigation Links */}
            <nav className="hidden lg:flex items-center gap-8 text-sm font-semibold text-slate-700">
              <a href="#" className="text-[#EA580C] hover:text-[#C2410C] transition-colors">
                Home
              </a>
              <a href="#about" className="hover:text-[#EA580C] transition-colors">
                About
              </a>
              <a href="#our-story" className="hover:text-[#EA580C] transition-colors flex items-center gap-1 font-bold text-[#1E3A8A]">
                <span>Our Story</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#EF4444]" />
              </a>
              <a href="#services" className="hover:text-[#EA580C] transition-colors">
                Our Services
              </a>
              <a href="#signals" className="hover:text-[#EA580C] transition-colors flex items-center gap-1">
                <span>Strength & Signals</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              </a>
              <button
                onClick={onOpenContact}
                className="hover:text-[#EA580C] transition-colors cursor-pointer"
              >
                Contact
              </button>
            </nav>

            {/* Right Action: MAKE APPOINTMENT Button */}
            <div className="hidden sm:flex items-center gap-3 shrink-0">
              <button
                onClick={onOpenAppointment}
                className="px-6 py-3 rounded-full border-2 border-slate-800 text-slate-900 hover:bg-slate-900 hover:text-white font-extrabold text-xs tracking-wider uppercase transition-all duration-200 flex items-center gap-2 cursor-pointer shadow-sm group"
              >
                <span>MAKE APPOINTMENT</span>
                <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </button>
            </div>

            {/* Mobile Hamburger */}
            <div className="flex lg:hidden items-center">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-slate-700 hover:text-slate-900"
                aria-label="Toggle Navigation"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3">
            <nav className="flex flex-col space-y-2 text-sm font-semibold text-slate-700">
              <a href="#" onClick={() => setMobileMenuOpen(false)} className="text-[#EA580C] py-1.5">
                Home
              </a>
              <a href="#about" onClick={() => setMobileMenuOpen(false)} className="py-1.5 hover:text-[#EA580C]">
                About
              </a>
              <a href="#our-story" onClick={() => setMobileMenuOpen(false)} className="py-1.5 hover:text-[#EA580C] font-bold text-[#1E3A8A]">
                Our Story (Founder & Videos)
              </a>
              <a href="#services" onClick={() => setMobileMenuOpen(false)} className="py-1.5 hover:text-[#EA580C]">
                Our Services
              </a>
              <a href="#signals" onClick={() => setMobileMenuOpen(false)} className="py-1.5 hover:text-[#EA580C]">
                Signals
              </a>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenContact();
                }}
                className="text-left py-1.5 hover:text-[#EA580C]"
              >
                Contact
              </button>
            </nav>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAppointment();
              }}
              className="w-full py-3 rounded-full bg-slate-900 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 mt-2"
            >
              <span>MAKE APPOINTMENT</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </header>
    </div>
  );
};
