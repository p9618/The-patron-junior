import React from 'react';
import officialLogoImg from '../assets/The_Patron_Forex_Hub_Emblem.png';

export const OFFICIAL_LOGO_URL = officialLogoImg || '/assets/aistudio/The_Patron_Forex_Hub_Emblem_0e4087aa.png';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showBadge?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ size = 'md', showBadge = true }) => {
  return (
    <div className="flex items-center gap-3 select-none">
      {/* Official Emblem Image */}
      <div className="relative shrink-0 w-11 h-11 sm:w-12 sm:h-12 rounded-full overflow-hidden border-2 border-[#F59E0B] shadow-md bg-[#070E22]">
        <img
          src={OFFICIAL_LOGO_URL}
          alt="The Patron Junior Forex Hub"
          className="w-full h-full object-cover"
          loading="eager"
        />
      </div>

      {/* Brand Text Lockup */}
      <div className="flex flex-col leading-tight">
        <div className="flex items-center gap-2">
          <span className="font-display font-black text-lg sm:text-xl tracking-tight text-[#0B1E48]">
            PATRON <span className="text-[#EA580C]">JUNIOR</span>
          </span>
          {showBadge && (
            <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold text-white bg-[#1D4ED8] rounded-md tracking-wider">
              Certified
            </span>
          )}
        </div>
        <span className="text-[10px] sm:text-[11px] font-bold font-mono tracking-wider uppercase text-slate-500">
          FOREX HUB <span className="text-[#DC2626]">·</span> KENYA & GLOBAL
        </span>
      </div>
    </div>
  );
};
