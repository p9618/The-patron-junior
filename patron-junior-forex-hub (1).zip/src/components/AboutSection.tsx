import React from 'react';
import { Target, Eye, Compass, ShieldCheck, Flame, Award, CheckCircle2 } from 'lucide-react';
import { OFFICIAL_LOGO_URL } from './BrandLogo';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-[#040D27] border-b border-[#1E3A8A]/40 text-slate-100 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[500px] h-[500px] bg-[#1E3A8A]/15 blur-[140px] pointer-events-none rounded-full" />
      <div className="absolute top-1/3 right-1/4 w-[350px] h-[350px] bg-[#F59E0B]/10 blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#0A1633] border border-[#F59E0B]/50 text-xs font-mono font-bold text-[#F59E0B] uppercase tracking-wider">
            <Flame className="w-3.5 h-3.5 text-[#EF4444]" />
            <span>TRADE TO WITHDRAW ALWAYS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white font-display tracking-tight">
            About The Patron Junior Forex Hub
          </h2>
          <p className="text-base text-slate-300 font-sans leading-relaxed">
            Welcome to The Patron Junior Forex Hub – Trade to Withdraw Always.
          </p>
        </div>

        {/* Main Brand Narrative Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          {/* Left Text */}
          <div className="lg:col-span-7 space-y-6">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-display leading-snug">
              Forex Trading Education & Mentorship Built for Consistency
            </h3>

            <p className="text-base text-slate-300 leading-relaxed">
              The Patron Junior Forex Hub is a forex trading education and mentorship brand committed to helping traders develop the knowledge, discipline, and skills needed to navigate the financial markets.
            </p>

            <div className="p-5 rounded-2xl bg-[#0A1633] border-l-4 border-[#F59E0B] border-y border-r border-[#1E3A8A]/50 space-y-2">
              <span className="text-xs font-bold font-mono text-[#F59E0B] uppercase tracking-wider block">
                Primary Market Specialization
              </span>
              <p className="text-sm text-slate-200 leading-relaxed">
                We focus primarily on <strong>Gold (XAUUSD)</strong>, using <strong>Smart Money Concepts (SMC)</strong>, <strong>Supply and Demand</strong>, <strong>Price Action</strong>, <strong>Liquidity Analysis</strong>, and <strong>Fundamental Analysis</strong> to identify high-probability potential trading opportunities.
              </p>
            </div>

            {/* Why Choose Us 5-Point Checklist */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-[#F59E0B]">
                Why Choose Us?
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-200">
                <div className="flex items-center gap-2.5 p-3 rounded-xl bg-[#071330] border border-[#1E3A8A]/50">
                  <CheckCircle2 className="w-4 h-4 text-[#F59E0B] shrink-0" />
                  <span>Practical market education</span>
                </div>
                <div className="flex items-center gap-2.5 p-3 rounded-xl bg-[#071330] border border-[#1E3A8A]/50">
                  <CheckCircle2 className="w-4 h-4 text-[#F59E0B] shrink-0" />
                  <span>Smart Money Concepts & price action</span>
                </div>
                <div className="flex items-center gap-2.5 p-3 rounded-xl bg-[#071330] border border-[#1E3A8A]/50">
                  <CheckCircle2 className="w-4 h-4 text-[#EF4444] shrink-0" />
                  <span>Focus on risk management & discipline</span>
                </div>
                <div className="flex items-center gap-2.5 p-3 rounded-xl bg-[#071330] border border-[#1E3A8A]/50">
                  <CheckCircle2 className="w-4 h-4 text-[#F59E0B] shrink-0" />
                  <span>Supportive trading community</span>
                </div>
                <div className="flex items-center gap-2.5 p-3 rounded-xl bg-[#071330] border border-[#1E3A8A]/50 col-span-1 sm:col-span-2">
                  <CheckCircle2 className="w-4 h-4 text-[#22C55E] shrink-0" />
                  <span>Continuous learning & hands-on mentorship</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Visual Emblem Showcase */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center">
            <div className="relative p-6 rounded-3xl bg-[#0A1633] border-2 border-[#1E3A8A] shadow-2xl flex flex-col items-center text-center max-w-sm">
              <div className="w-48 h-48 sm:w-56 sm:h-56 rounded-full overflow-hidden border-4 border-[#F59E0B] shadow-[0_0_40px_rgba(245,158,11,0.25)] mb-4 bg-[#070E22]">
                <img
                  src={OFFICIAL_LOGO_URL}
                  alt="The Patron Junior Forex Hub"
                  className="w-full h-full object-cover"
                />
              </div>
              <h4 className="text-lg font-black text-white font-display">
                THE PATRON JUNIOR
              </h4>
              <span className="text-xs font-bold text-[#F59E0B] font-mono tracking-widest uppercase mt-0.5">
                OUR MOTTO: TRADE TO WITHDRAW ALWAYS
              </span>
              <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                Join The Patron Junior Forex Hub and take your trading journey to the next level.
              </p>
            </div>
          </div>
        </div>

        {/* Mission & Vision 2-Column Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Mission Card */}
          <div className="p-8 rounded-3xl bg-[#0A1633] border-2 border-[#1E3A8A] hover:border-[#F59E0B]/70 transition-all shadow-xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-[#071330] border border-[#F59E0B] text-[#F59E0B] flex items-center justify-center">
              <Target className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-mono font-bold text-[#F59E0B] uppercase tracking-wider">
                CORE PURPOSE
              </span>
              <h3 className="text-2xl font-black text-white font-display mt-1">
                OUR MISSION
              </h3>
            </div>
            <p className="text-base text-slate-200 leading-relaxed font-sans">
              "To equip traders with practical forex knowledge, strong risk management skills, and the discipline required for long-term trading development."
            </p>
          </div>

          {/* Vision Card */}
          <div className="p-8 rounded-3xl bg-[#0A1633] border-2 border-[#1E3A8A] hover:border-[#F59E0B]/70 transition-all shadow-xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-[#071330] border border-[#2563EB] text-[#38BDF8] flex items-center justify-center">
              <Eye className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-mono font-bold text-[#38BDF8] uppercase tracking-wider">
                FUTURE HORIZON
              </span>
              <h3 className="text-2xl font-black text-white font-display mt-1">
                OUR VISION
              </h3>
            </div>
            <p className="text-base text-slate-200 leading-relaxed font-sans">
              "To become a trusted forex education and trading community, developing confident, knowledgeable, and disciplined traders."
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
