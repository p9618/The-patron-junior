import React from 'react';
import { ECONOMIC_CALENDAR } from '../data/mockData';
import { ShieldCheck, Zap, AlertTriangle, ExternalLink, Calendar, Check } from 'lucide-react';

export const BrokerAndNews: React.FC = () => {
  return (
    <section className="py-16 sm:py-24 bg-[#070E22] border-b border-[#1E3A8A]/40 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          {/* Left Column: Recommended Regulated Broker Setup */}
          <div className="lg:col-span-7 bg-[#0A1633] border border-[#1E3A8A] rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 text-xs text-slate-400">
                <span className="text-[#FACC15] font-bold uppercase tracking-wider font-mono">
                  Official Broker Recommendation
                </span>
                <span aria-hidden="true">·</span>
                <span>FCA & CySEC Regulated</span>
              </div>

              <h3 className="text-2xl font-extrabold text-white font-display">
                Trade with Institutional Raw Spreads & Instant Local Withdrawals
              </h3>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Broker spreads determine whether your sniper entries hold or get prematurely stopped out. We partner with Tier-1 ECN liquidity providers offering true 0.0 pip raw spreads on Gold and currency pairs.
              </p>

              {/* Broker Key Highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3.5 rounded-xl bg-[#070E22] border border-[#1E3A8A]/60 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#1E3A8A]/40 text-[#FACC15] flex items-center justify-center shrink-0">
                    <Zap className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-white text-xs block font-display">0.0 Pip Raw Spreads</strong>
                    <span className="text-[11px] text-slate-400">Zero markup on XAUUSD & EURUSD</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#070E22] border border-[#1E3A8A]/60 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#1E3A8A]/40 text-emerald-400 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-white text-xs block font-display">Instant Mobile Payouts</strong>
                    <span className="text-[11px] text-slate-400">M-Pesa, Local Bank Wire, & USDT</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#070E22] border border-[#1E3A8A]/60 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#1E3A8A]/40 text-[#EF4444] flex items-center justify-center shrink-0">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-white text-xs block font-display">1:500 Leverage Available</strong>
                    <span className="text-[11px] text-slate-400">Flexible margin for qualified accounts</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#070E22] border border-[#1E3A8A]/60 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#1E3A8A]/40 text-[#FACC15] flex items-center justify-center shrink-0">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-white text-xs block font-display">Swap-Free Islamic Option</strong>
                    <span className="text-[11px] text-slate-400">No overnight holding interest charges</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Broker Action */}
            <div className="pt-4 border-t border-[#1E3A8A]/60 flex flex-col sm:flex-row items-center justify-between gap-4">
              <span className="text-xs text-slate-400">
                Hub members receive a <strong>100% Deposit Bonus</strong> up to $500 on their first deposit.
              </span>
              <a
                href="https://one.exness-track.com"
                target="_blank"
                rel="noreferrer"
                className="w-full sm:w-auto px-5 py-2.5 bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer"
              >
                <span>Open Partner Raw Account</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Right Column: High-Impact Economic Calendar Radar */}
          <div className="lg:col-span-5 bg-[#0A1633] border border-[#1E3A8A] rounded-2xl p-6 sm:p-8 space-y-5 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-mono text-[#EF4444] font-bold">
                  <Calendar className="w-4 h-4" />
                  <span>HIGH IMPACT RADAR</span>
                </div>
                <span className="text-[11px] text-slate-400 font-mono">This Week's Key Releases</span>
              </div>

              <h4 className="text-lg font-bold text-white font-display">
                Institutional Macro Calendar
              </h4>
              <p className="text-xs text-slate-300">
                Never hold naked positions into high-tier red folder news. Patron Junior signals adjust risk or close exposure prior to major volatility events.
              </p>

              {/* Event rows */}
              <div className="space-y-2.5">
                {ECONOMIC_CALENDAR.map((ev) => (
                  <div
                    key={ev.id}
                    className="p-3 rounded-xl bg-[#070E22] border border-[#1E3A8A]/50 flex items-center justify-between text-xs"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-white px-1.5 py-0.5 rounded bg-[#1E3A8A]/60 text-[11px]">
                          {ev.currency}
                        </span>
                        <span className="text-slate-200 font-medium truncate max-w-[180px] sm:max-w-[220px]">
                          {ev.event}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {ev.time} · Forecast: {ev.forecast} (Prev: {ev.previous})
                      </div>
                    </div>

                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        ev.impact === 'HIGH'
                          ? 'bg-red-950/80 text-[#EF4444] border border-[#EF4444]/40'
                          : 'bg-amber-950/80 text-[#FACC15] border border-[#FACC15]/40'
                      }`}
                    >
                      {ev.impact}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-3 bg-[#070E22] rounded-xl border border-[#EF4444]/40 text-[11px] text-slate-300 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-[#EF4444] shrink-0 mt-0.5" />
              <span>
                <strong>Warning:</strong> High slippage occurs during NFP and CPI announcements. VIP signals pause 15 minutes before and resume after structure confirms.
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
