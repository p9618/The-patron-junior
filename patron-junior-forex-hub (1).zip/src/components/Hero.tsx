import React from 'react';
import { ArrowUpRight, Phone, CheckCircle2 } from 'lucide-react';
import { OFFICIAL_LOGO_URL } from './BrandLogo';

interface HeroProps {
  onOpenContact: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenContact }) => {
  return (
    <section className="relative overflow-hidden bg-[#040D27] text-white pt-10 pb-20 lg:pt-16 lg:pb-28">
      {/* Background Cyber Tech Grid & Ambient Glows */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(14,116,144,0.25),rgba(255,255,255,0))]" />
      <div className="absolute top-1/4 right-10 w-[500px] h-[500px] bg-[#1D4ED8]/15 blur-[140px] pointer-events-none rounded-full" />
      <div className="absolute bottom-10 left-10 w-[350px] h-[350px] bg-[#EA580C]/10 blur-[120px] pointer-events-none rounded-full" />

      {/* Hexagon Pattern Ambient Elements */}
      <div className="absolute bottom-8 right-12 hidden lg:flex items-center gap-2 opacity-30 pointer-events-none">
        <div className="w-12 h-12 border border-blue-400/40 rotate-45" />
        <div className="w-16 h-16 border-2 border-amber-500/50 rotate-45 bg-[#EA580C]/10" />
        <div className="w-8 h-8 border border-blue-400/40 rotate-45" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Copy, Headline & Action */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Overline with tech circuit line from screenshot */}
            <div className="flex items-center gap-3">
              <span className="font-mono text-xs sm:text-sm font-bold tracking-widest uppercase text-white/95">
                WELCOME TO THE PATRON JUNIOR FOREX HUB
              </span>
              <div className="hidden sm:flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded-full bg-[#38BDF8]" />
                <div className="w-12 h-[2px] bg-gradient-to-r from-[#38BDF8] to-transparent" />
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="w-2 h-2.5 bg-blue-500/40 rounded-xs" />
                  ))}
                </div>
              </div>
            </div>

            {/* Big Bold Headline in Vibrant Orange/Amber */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-display tracking-tight text-[#F97316] leading-[1.12]">
              We don't just teach Forex, we shape profitable traders.
            </h1>

            {/* Description Paragraph */}
            <p className="text-base sm:text-lg text-slate-200 leading-relaxed font-sans max-w-2xl font-normal">
              We are a premium forex training and mentorship platform committed to transforming aspiring traders into disciplined, consistent, and profitable market participants. Founded by an experienced trader with over 6 years of live trading success, we focus on real results, not hype. Whether you're a beginner or seeking prop firm funding, we'll guide you step-by-step.
            </p>

            {/* Bullet List from Screenshot */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-3 text-sm sm:text-base font-semibold text-white">
                <div className="w-5 h-5 rounded-full border-2 border-[#F97316] flex items-center justify-center shrink-0">
                  <div className="w-2 h-2 rounded-full bg-[#F97316]" />
                </div>
                <span>Focus on quality first</span>
              </div>

              <div className="flex items-center gap-3 text-sm sm:text-base font-semibold text-white">
                <div className="w-5 h-5 rounded-full border-2 border-[#F97316] flex items-center justify-center shrink-0">
                  <div className="w-2 h-2 rounded-full bg-[#F97316]" />
                </div>
                <span>Get to the market on time</span>
              </div>

              <div className="flex items-center gap-3 text-sm sm:text-base font-semibold text-white">
                <div className="w-5 h-5 rounded-full border-2 border-[#F97316] flex items-center justify-center shrink-0">
                  <div className="w-2 h-2 rounded-full bg-[#F97316]" />
                </div>
                <span>Trade to withdraw always</span>
              </div>
            </div>

            {/* Action Buttons: Contact Us Today + Phone Call Pill */}
            <div className="flex flex-wrap items-center gap-6 pt-4">
              {/* Big Orange Button */}
              <button
                onClick={onOpenContact}
                className="px-8 py-4 bg-[#EA580C] hover:bg-[#C2410C] text-white font-extrabold text-sm sm:text-base rounded-full shadow-lg shadow-[#EA580C]/30 flex items-center gap-2 cursor-pointer transition-all duration-200 group"
              >
                <span>CONTACT US TODAY!</span>
                <ArrowUpRight className="w-5 h-5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </button>

              {/* Call & Direct Channels */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                <a
                  href="tel:+254740076628"
                  className="flex items-center gap-3 group select-none cursor-pointer"
                >
                  <div className="w-12 h-12 rounded-full bg-[#22C55E] group-hover:bg-[#16A34A] text-white flex items-center justify-center shadow-md transition-colors shrink-0">
                    <Phone className="w-5 h-5 fill-white" />
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider font-mono">
                      CALL / WHATSAPP / TELEGRAM
                    </span>
                    <span className="text-sm sm:text-base font-black text-white font-mono tracking-tight group-hover:text-[#F97316] transition-colors">
                      +254-740-076-628
                    </span>
                  </div>
                </a>

                {/* Official Community Channel Badges */}
                <div className="flex flex-wrap items-center gap-2">
                  <a
                    href="https://chat.whatsapp.com/FYzi5id1fLl7kIZUsvl3iO"
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-[#22C55E]/20 hover:bg-[#22C55E] text-emerald-400 hover:text-white border border-[#22C55E]/40 text-xs font-mono font-bold transition-all flex items-center gap-1.5"
                  >
                    <span>Join WhatsApp</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>
                  <a
                    href="https://t.me/THEPATRONJUNIOURFOREXHUB"
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-[#0284C7]/20 hover:bg-[#0284C7] text-sky-400 hover:text-white border border-[#0284C7]/40 text-xs font-mono font-bold transition-all flex items-center gap-1.5"
                  >
                    <span>Join Telegram</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Futuristic Tech Circle with Official Emblem & Rotating MT5, MT4, TradingView Logos */}
          <div className="lg:col-span-5 flex items-center justify-center relative mt-8 lg:mt-0">
            {/* Tech HUD Ring Container (Matches user screenshot image_f89fe944.png) */}
            <div className="relative w-[360px] h-[360px] sm:w-[460px] sm:h-[460px] flex items-center justify-center">
              {/* Outer Deep Orbit Glow Rings */}
              <div className="absolute inset-0 rounded-full border border-cyan-500/20" />
              
              {/* Main Visible Circular Orbit Track Line (where logos rotate along) */}
              <div className="absolute w-[290px] h-[290px] sm:w-[380px] sm:h-[380px] rounded-full border-2 border-cyan-400/50 shadow-[0_0_20px_rgba(6,182,212,0.3)] pointer-events-none" />
              <div className="absolute w-[310px] h-[310px] sm:w-[400px] sm:h-[400px] rounded-full border border-blue-500/30 border-dashed animate-[spin_60s_linear_infinite] pointer-events-none" />
              <div className="absolute w-[260px] h-[260px] sm:w-[340px] sm:h-[340px] rounded-full border border-sky-400/30 pointer-events-none" />

              {/* ROTATING ORBIT CONTAINER: Carries MT5, MT4, and TradingView around the central emblem along the line */}
              <div className="absolute w-[290px] h-[290px] sm:w-[380px] sm:h-[380px] rounded-full animate-orbit pointer-events-none z-20">
                {/* 1. Real MetaTrader 5 (MT5) Logo (Position: 0° / 12 o'clock / Top) */}
                <div
                  className="absolute pointer-events-auto cursor-pointer group"
                  style={{ top: '0%', left: '50%', transform: 'translate(-50%, -50%)' }}
                  title="MetaTrader 5 (MT5) - Real Trading Terminal"
                >
                  <div className="animate-orbit-counter">
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#040D27]/95 border-2 border-sky-400 shadow-[0_0_25px_rgba(56,189,248,0.55)] flex flex-col items-center justify-center p-1.5 hover:scale-115 transition-all">
                      <img
                        src="/assets/platforms/mt5_logo.png"
                        alt="MetaTrader 5 Real Logo"
                        className="w-7 h-7 sm:w-8 sm:h-8 object-contain drop-shadow"
                      />
                      <span className="text-[8px] sm:text-[9px] font-mono font-black text-sky-400 tracking-wider">MT5</span>
                    </div>
                  </div>
                </div>

                {/* 2. Real TradingView Logo (Position: 120° / 4 o'clock / Bottom-Right) */}
                <div
                  className="absolute pointer-events-auto cursor-pointer group"
                  style={{ top: '75%', left: '93.3%', transform: 'translate(-50%, -50%)' }}
                  title="TradingView - Real Charting Platform"
                >
                  <div className="animate-orbit-counter">
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#040D27]/95 border-2 border-[#2962FF] shadow-[0_0_25px_rgba(41,98,255,0.55)] flex flex-col items-center justify-center p-1.5 hover:scale-115 transition-all">
                      <img
                        src="/assets/platforms/tradingview_logo.png"
                        alt="TradingView Real Logo"
                        className="w-8 h-6 sm:w-9 sm:h-7 object-contain drop-shadow"
                      />
                      <span className="text-[7px] sm:text-[8px] font-mono font-black text-blue-400 tracking-tight">TradingView</span>
                    </div>
                  </div>
                </div>

                {/* 3. Real MetaTrader 4 (MT4) Logo (Position: 240° / 8 o'clock / Bottom-Left) */}
                <div
                  className="absolute pointer-events-auto cursor-pointer group"
                  style={{ top: '75%', left: '6.7%', transform: 'translate(-50%, -50%)' }}
                  title="MetaTrader 4 (MT4) - Real Trading Terminal"
                >
                  <div className="animate-orbit-counter">
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#040D27]/95 border-2 border-[#F59E0B] shadow-[0_0_25px_rgba(245,158,11,0.55)] flex flex-col items-center justify-center p-1.5 hover:scale-115 transition-all">
                      <img
                        src="/assets/platforms/mt4_logo.png"
                        alt="MetaTrader 4 Real Logo"
                        className="w-7 h-7 sm:w-8 sm:h-8 object-contain drop-shadow"
                      />
                      <span className="text-[8px] sm:text-[9px] font-mono font-black text-[#F59E0B] tracking-wider">MT4</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Center Official Emblem Medallion */}
              <div className="relative z-10 w-48 h-48 sm:w-60 sm:h-60 rounded-full bg-[#040D27] p-2.5 border-4 border-[#F59E0B] shadow-[0_0_60px_rgba(245,158,11,0.4)] flex items-center justify-center">
                <img
                  src={OFFICIAL_LOGO_URL}
                  alt="The Patron Junior Forex Hub Emblem"
                  className="w-full h-full object-cover rounded-full"
                  loading="eager"
                />
              </div>

              {/* Live Status Floating Tag */}
              <div className="absolute -bottom-3 sm:bottom-1 z-30 px-4 py-1.5 rounded-full bg-[#071330]/95 border border-[#F59E0B] text-xs font-mono font-bold text-[#F59E0B] shadow-xl flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>ACTIVE TRADING FLOOR</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
