import React, { useState } from 'react';
import { MessageSquareText, Phone, Send, Mail, X } from 'lucide-react';

interface ContactWidgetProps {
  onClick: () => void;
}

export const ContactWidget: React.FC<ContactWidgetProps> = ({ onClick }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="fixed bottom-6 left-6 z-50 flex flex-col items-start gap-2 select-none">
      {/* Expanded Quick Contact Panel */}
      {expanded && (
        <div className="bg-[#0A1633] border-2 border-[#1E3A8A] rounded-2xl p-4 shadow-2xl text-xs space-y-2.5 text-white animate-in slide-in-from-bottom-2 duration-200 min-w-[240px]">
          <div className="flex items-center justify-between pb-2 border-b border-[#1E3A8A]/60">
            <span className="font-bold text-[#F97316] font-mono text-[11px]">PATRON JUNIOR DESK</span>
            <button
              onClick={() => setExpanded(false)}
              className="text-slate-400 hover:text-white p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <a
            href="https://chat.whatsapp.com/FYzi5id1fLl7kIZUsvl3iO"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2.5 p-2 rounded-xl bg-[#22C55E]/15 hover:bg-[#22C55E] text-slate-100 hover:text-white transition-colors"
          >
            <div className="w-6 h-6 rounded-full bg-[#22C55E] text-white flex items-center justify-center shrink-0">
              <MessageSquareText className="w-3.5 h-3.5" />
            </div>
            <div>
              <strong className="block text-[11px]">Join WhatsApp Channel</strong>
              <span className="text-[10px] text-slate-300 font-mono">+254 740 076 628</span>
            </div>
          </a>

          <a
            href="tel:+254740076628"
            className="flex items-center gap-2.5 p-2 rounded-xl bg-blue-900/30 hover:bg-blue-600 text-slate-100 hover:text-white transition-colors"
          >
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0">
              <Phone className="w-3.5 h-3.5" />
            </div>
            <div>
              <strong className="block text-[11px]">Direct Phone Call</strong>
              <span className="text-[10px] text-slate-300 font-mono">+254 740 076 628</span>
            </div>
          </a>

          <a
            href="https://t.me/THEPATRONJUNIOURFOREXHUB"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2.5 p-2 rounded-xl bg-sky-900/30 hover:bg-sky-600 text-slate-100 hover:text-white transition-colors"
          >
            <div className="w-6 h-6 rounded-full bg-sky-500 text-white flex items-center justify-center shrink-0">
              <Send className="w-3.5 h-3.5" />
            </div>
            <div>
              <strong className="block text-[11px]">Join Telegram Channel</strong>
              <span className="text-[10px] text-slate-300 font-mono">@THEPATRONJUNIOURFOREXHUB</span>
            </div>
          </a>

          <a
            href="mailto:thepatronjuniour@gmail.com"
            className="flex items-center gap-2.5 p-2 rounded-xl bg-orange-950/40 hover:bg-[#EA580C] text-slate-100 hover:text-white transition-colors"
          >
            <div className="w-6 h-6 rounded-full bg-[#EA580C] text-white flex items-center justify-center shrink-0">
              <Mail className="w-3.5 h-3.5" />
            </div>
            <div className="truncate">
              <strong className="block text-[11px]">Send an Email</strong>
              <span className="text-[10px] text-slate-300 truncate">thepatronjuniour@gmail.com</span>
            </div>
          </a>
        </div>
      )}

      {/* Main Pill Button */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-white text-slate-900 shadow-2xl border border-slate-200/90 hover:shadow-2xl hover:scale-105 transition-all duration-200 cursor-pointer group"
      >
        <div className="w-7 h-7 rounded-full bg-[#1D4ED8] text-white flex items-center justify-center shrink-0">
          <MessageSquareText className="w-4 h-4" />
        </div>
        <span className="text-xs font-bold font-sans tracking-tight text-slate-800 group-hover:text-[#EA580C] transition-colors">
          Contact us
        </span>
      </button>
    </div>
  );
};
