import React, { useState } from 'react';
import { X, Check, Phone, Send, ArrowRight } from 'lucide-react';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppointmentModal: React.FC<AppointmentModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [service, setService] = useState('1-on-1 Mentorship & Trading Desk');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) {
      alert('Please fill in your name and phone number.');
      return;
    }
    setSubmitted(true);
  };

  const handleClose = () => {
    setSubmitted(false);
    setName('');
    setPhone('');
    setEmail('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 text-slate-900">
        {/* Header */}
        <div className="px-6 py-5 bg-[#040D27] text-white flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#F97316]">
              The Patron Junior Forex Hub
            </span>
            <h3 className="text-lg font-extrabold font-display">
              {submitted ? 'Appointment Request Received!' : 'Make an Appointment'}
            </h3>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {submitted ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                <Check className="w-8 h-8 stroke-[3]" />
              </div>
              <h4 className="text-xl font-bold font-display text-slate-900">
                Thank You, {name}!
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto">
                We have received your appointment request for <strong>{service}</strong>. A senior desk trader will contact you on <strong>{phone}</strong> within 15 minutes.
              </p>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-[#22C55E]" />
                  <span>Call / WhatsApp / Telegram: <strong>+254 740 076 628</strong></span>
                </div>
                <div className="text-[11px] text-slate-500">
                  Email: <a href="mailto:thepatronjuniour@gmail.com" className="text-[#EA580C] underline font-bold">thepatronjuniour@gmail.com</a>
                </div>
              </div>
              <button
                type="button"
                onClick={handleClose}
                className="w-full py-3 bg-[#EA580C] hover:bg-[#C2410C] text-white font-bold text-xs uppercase rounded-full shadow-md"
              >
                Close Window
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Your Full Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Jacob Vundi"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-[#EA580C]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Phone / WhatsApp Number
                </label>
                <input
                  type="text"
                  required
                  placeholder="+254 7..."
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-[#EA580C]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="yourname@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-[#EA580C]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Select Hub Service
                </label>
                <select
                  value={service}
                  onChange={(e) => setService(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-[#EA580C]"
                >
                  <option>1-on-1 Mentorship & Physical Trading Desk</option>
                  <option>VIP Signals Telegram Community</option>
                  <option>Prop Firm Funding Challenge Coaching (FTMO/The5ers)</option>
                  <option>Beginner to Pro Forex Bootcamp</option>
                </select>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#EA580C] hover:bg-[#C2410C] text-white font-extrabold text-xs uppercase tracking-wider rounded-full shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Submit Appointment Request</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center justify-center gap-4 pt-2 text-[11px] text-slate-600">
                <span>Call/WhatsApp: <a href="tel:+254740076628" className="font-bold text-[#EA580C] underline">+254-740-076-628</a></span>
                <span>·</span>
                <a href="mailto:thepatronjuniour@gmail.com" className="font-bold text-[#EA580C] underline">thepatronjuniour@gmail.com</a>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
