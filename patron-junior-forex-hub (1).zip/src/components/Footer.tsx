import React from 'react';
import { BrandLogo } from './BrandLogo';
import { Send, ArrowUp, ShieldAlert, Phone, Mail, MessageSquare } from 'lucide-react';

interface FooterProps {
  onOpenEnrollModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenEnrollModal }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#030A20] border-t border-[#1E3A8A]/50 text-slate-400 text-xs">
      {/* Top CTA Banner */}
      <div className="border-b border-[#1E3A8A]/40 bg-[#061133] py-8 px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-3xl mx-auto space-y-3">
          <h3 className="text-xl sm:text-2xl font-bold text-white font-display">
            Start Trading Institutional Setups Today
          </h3>
          <p className="text-slate-300 text-xs sm:text-sm">
            Join the Patron Junior Forex Hub community and trade with precision.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            <a
              href="https://chat.whatsapp.com/FYzi5id1fLl7kIZUsvl3iO"
              target="_blank"
              rel="noreferrer"
              className="px-5 py-2.5 bg-[#22C55E] hover:bg-[#16A34A] text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Join Official WhatsApp Channel</span>
            </a>
            <a
              href="https://t.me/THEPATRONJUNIOURFOREXHUB"
              target="_blank"
              rel="noreferrer"
              className="px-5 py-2.5 bg-[#0284C7] hover:bg-[#0369A1] text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Join Official Telegram Channel</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-8 border-b border-[#1E3A8A]/40 items-center">
          {/* Logo & Slogan */}
          <div className="md:col-span-5 space-y-2">
            <BrandLogo size="md" />
            <p className="text-slate-400 text-xs font-mono">
              Trade To Withdraw Always · Kenya & Global
            </p>
          </div>

          {/* Direct Contact Details */}
          <div className="md:col-span-4 space-y-1.5 text-xs">
            <div className="flex items-center gap-2 text-slate-200">
              <Phone className="w-4 h-4 text-[#22C55E]" />
              <span>Call / WhatsApp / Telegram:</span>
              <a href="tel:+254740076628" className="font-bold text-white hover:text-[#EA580C] font-mono">
                +254 740 076 628
              </a>
            </div>
            <div className="flex items-center gap-2 text-slate-200">
              <Mail className="w-4 h-4 text-[#F59E0B]" />
              <span>Email:</span>
              <a href="mailto:thepatronjuniour@gmail.com" className="font-bold text-[#EA580C] hover:underline font-mono">
                thepatronjuniour@gmail.com
              </a>
            </div>
          </div>

          {/* Social Badges */}
          <div className="md:col-span-3 flex md:justify-end gap-2">
            <a
              href="https://chat.whatsapp.com/FYzi5id1fLl7kIZUsvl3iO"
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-lg bg-[#22C55E]/15 hover:bg-[#22C55E] text-[#22C55E] hover:text-white border border-[#22C55E]/40 text-xs font-mono font-bold transition-all"
            >
              WhatsApp
            </a>
            <a
              href="https://t.me/THEPATRONJUNIOURFOREXHUB"
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-lg bg-[#0284C7]/15 hover:bg-[#0284C7] text-sky-400 hover:text-white border border-[#0284C7]/40 text-xs font-mono font-bold transition-all"
            >
              Telegram
            </a>
            <a
              href="mailto:thepatronjuniour@gmail.com"
              className="px-3 py-1.5 rounded-lg bg-[#EA580C]/15 hover:bg-[#EA580C] text-[#EA580C] hover:text-white border border-[#EA580C]/40 text-xs font-mono font-bold transition-all"
            >
              Gmail
            </a>
          </div>
        </div>

        {/* Official Risk Disclaimer */}
        <div className="py-6 space-y-1 text-[11px] text-slate-400 leading-relaxed border-t border-[#1E3A8A]/30">
          <div className="flex items-center gap-1.5 text-[#EF4444] font-bold font-mono">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>DISCLAIMER</span>
          </div>
          <p>
            Disclaimer: Forex trading involves significant risk and may result in the loss of your invested capital. We do not guarantee profits or returns.
          </p>
        </div>

        {/* Copyright */}
        <div className="pt-4 border-t border-[#1E3A8A]/30 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px]">
          <p>© {new Date().getFullYear()} The Patron Junior Forex Hub. All rights reserved.</p>
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1 text-slate-400 hover:text-[#EA580C]"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3 h-3" />
          </button>
        </div>
      </div>
    </footer>
  );
};
