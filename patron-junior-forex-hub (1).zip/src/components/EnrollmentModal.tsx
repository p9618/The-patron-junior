import React, { useState } from 'react';
import { MENTORSHIP_TIERS } from '../data/mockData';
import { X, Check, ShieldCheck, Send, ArrowRight, CreditCard, Smartphone } from 'lucide-react';

interface EnrollmentModalProps {
  isOpen: boolean;
  tierId: string;
  onClose: () => void;
}

export const EnrollmentModal: React.FC<EnrollmentModalProps> = ({ isOpen, tierId, onClose }) => {
  const [selectedTierId, setSelectedTierId] = useState<string>(tierId || 'vip-signals');
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [email, setEmail] = useState('');
  const [experience, setExperience] = useState('Intermediate (Trading 6+ months)');
  const [paymentMethod, setPaymentMethod] = useState<'mpesa' | 'card' | 'crypto'>('mpesa');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const currentTier = MENTORSHIP_TIERS.find((t) => t.id === selectedTierId) || MENTORSHIP_TIERS[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !contact || !email) {
      alert('Please fill in your name, contact phone/telegram, and email.');
      return;
    }
    setIsSubmitted(true);
  };

  const handleResetAndClose = () => {
    setIsSubmitted(false);
    setName('');
    setContact('');
    setEmail('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-[#0A1633] border-2 border-[#1E3A8A] rounded-2xl shadow-2xl overflow-hidden text-slate-100 max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#070E22] border-b border-[#1E3A8A]/60 shrink-0">
          <div>
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#FACC15]">
              Patron Junior Forex Hub Enrollment
            </span>
            <h3 className="text-base sm:text-lg font-bold text-white font-display">
              {isSubmitted ? 'Enrollment Confirmed!' : `Join ${currentTier.name}`}
            </h3>
          </div>
          <button
            onClick={handleResetAndClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {isSubmitted ? (
            /* Confirmation Screen */
            <div className="text-center py-6 space-y-5">
              <div className="w-16 h-16 mx-auto rounded-full bg-emerald-950/90 border-2 border-emerald-400 flex items-center justify-center text-emerald-400">
                <Check className="w-8 h-8 stroke-[3]" />
              </div>

              <div className="space-y-2">
                <h4 className="text-xl font-extrabold text-white font-display">
                  Welcome to the Patron Junior Family, {name}!
                </h4>
                <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto">
                  Your registration for <strong>{currentTier.name} ({currentTier.price})</strong> has been received. Your Telegram invite key has been generated:
                </p>
              </div>

              {/* Official Community Invite Buttons */}
              <div className="max-w-sm mx-auto space-y-2">
                <a
                  href="https://t.me/THEPATRONJUNIOURFOREXHUB"
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-2.5 px-4 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md"
                >
                  <Send className="w-4 h-4" />
                  <span>Join Official Telegram Channel</span>
                </a>
                <a
                  href="https://chat.whatsapp.com/FYzi5id1fLl7kIZUsvl3iO"
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-2.5 px-4 rounded-xl bg-[#22C55E] hover:bg-[#16A34A] text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md"
                >
                  <span>Join Official WhatsApp Community</span>
                </a>
              </div>

              <div className="p-3 bg-[#13234F] rounded-xl border border-[#1E3A8A] text-xs text-slate-300 max-w-md mx-auto text-left flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-[#FACC15] shrink-0 mt-0.5" />
                <span>
                  Our onboarding desk will verify your details on WhatsApp/Telegram (<strong>+254 740 076 628</strong>) within 15 minutes. Official support email: <strong>thepatronjuniour@gmail.com</strong>.
                </span>
              </div>

              <button
                type="button"
                onClick={handleResetAndClose}
                className="w-full max-w-sm mx-auto py-3 bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-colors cursor-pointer"
              >
                Done & Return to Hub
              </button>
            </div>
          ) : (
            /* Enrollment Form */
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Tier Selector */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                  Select Program Tier
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {MENTORSHIP_TIERS.map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setSelectedTierId(t.id)}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        selectedTierId === t.id
                          ? 'bg-[#1E3A8A] border-[#FACC15] text-white ring-1 ring-[#FACC15]'
                          : 'bg-[#070E22] border-[#1E3A8A]/50 text-slate-300 hover:border-slate-500'
                      }`}
                    >
                      <span className="block text-xs font-bold font-display truncate">{t.name}</span>
                      <strong className="block text-xs font-mono text-[#FACC15] mt-0.5">{t.price}</strong>
                    </button>
                  ))}
                </div>
              </div>

              {/* Full Name */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Jacob Vundi"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#070E22] border border-[#1E3A8A] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#FACC15]"
                />
              </div>

              {/* Telegram / WhatsApp */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                  Telegram Username or WhatsApp Phone Number
                </label>
                <input
                  type="text"
                  required
                  placeholder="@yourhandle or +254 7..."
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  className="w-full bg-[#070E22] border border-[#1E3A8A] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#FACC15]"
                />
                <span className="text-[10px] text-slate-400 block font-mono">
                  Used immediately to send your VIP Channel invite and trade signals.
                </span>
              </div>

              {/* Email */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  placeholder="you@domain.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#070E22] border border-[#1E3A8A] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#FACC15]"
                />
              </div>

              {/* Experience */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                  Your Trading Experience
                </label>
                <select
                  value={experience}
                  onChange={(e) => setExperience(e.target.value)}
                  className="w-full bg-[#070E22] border border-[#1E3A8A] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#FACC15]"
                >
                  <option>Beginner (Less than 6 months, learning basics)</option>
                  <option>Intermediate (Trading 6+ months, seeking consistency)</option>
                  <option>Prop Firm Challenger (Preparing for FTMO/The5ers)</option>
                  <option>Advanced Trader (Funded trader optimizing execution)</option>
                </select>
              </div>

              {/* Payment Method Selector */}
              <div className="space-y-1.5 pt-1">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                  Preferred Payment Channel
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('mpesa')}
                    className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center ${
                      paymentMethod === 'mpesa'
                        ? 'bg-[#1E3A8A] border-[#FACC15] text-white ring-1 ring-[#FACC15]'
                        : 'bg-[#070E22] border-[#1E3A8A]/50 text-slate-300'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 text-emerald-400 mb-1" />
                    <span className="text-[11px] font-bold">M-Pesa / Mobile</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center ${
                      paymentMethod === 'card'
                        ? 'bg-[#1E3A8A] border-[#FACC15] text-white ring-1 ring-[#FACC15]'
                        : 'bg-[#070E22] border-[#1E3A8A]/50 text-slate-300'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 text-[#FACC15] mb-1" />
                    <span className="text-[11px] font-bold">Visa / Mastercard</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('crypto')}
                    className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center ${
                      paymentMethod === 'crypto'
                        ? 'bg-[#1E3A8A] border-[#FACC15] text-white ring-1 ring-[#FACC15]'
                        : 'bg-[#070E22] border-[#1E3A8A]/50 text-slate-300'
                    }`}
                  >
                    <Send className="w-4 h-4 text-[#EF4444] mb-1" />
                    <span className="text-[11px] font-bold">USDT (Crypto)</span>
                  </button>
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Complete Enrollment ({currentTier.price})</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <p className="text-[10px] text-center text-slate-400 mt-2 font-mono">
                  Instant Telegram Activation · 100% Secure Transaction
                </p>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
