import React from 'react';
import { BookOpen, Radio, TrendingUp, Briefcase, Layers, GraduationCap, ArrowRight } from 'lucide-react';

interface WhatWeOfferProps {
  onSelectService: (serviceName: string) => void;
}

export const WhatWeOffer: React.FC<WhatWeOfferProps> = ({ onSelectService }) => {
  const services = [
    {
      title: 'Forex Education',
      description: 'Beginner to advanced trading lessons designed for practical market mastery.',
      icon: BookOpen,
      iconColor: 'text-[#F59E0B]',
      borderHighlight: 'hover:border-[#F59E0B]',
      badge: 'Curriculum',
    },
    {
      title: 'VIP Signals',
      description: 'High-probability market opportunities and real-time trading setups with clear SL & TP targets.',
      icon: Radio,
      iconColor: 'text-[#38BDF8]',
      borderHighlight: 'hover:border-[#38BDF8]',
      badge: 'Real-Time',
    },
    {
      title: 'Gold Analysis',
      description: 'Deep technical and fundamental analysis of XAUUSD using Smart Money Concepts & liquidity.',
      icon: TrendingUp,
      iconColor: 'text-[#F59E0B]',
      borderHighlight: 'hover:border-[#F59E0B]',
      badge: 'Specialization',
    },
    {
      title: 'Account Management',
      description: 'Structured account management services operated with strictly agreed risk parameters.',
      icon: Briefcase,
      iconColor: 'text-[#EF4444]',
      borderHighlight: 'hover:border-[#EF4444]',
      badge: 'Structured',
    },
    {
      title: 'PAMM Services',
      description: 'Transparent investment participation opportunities under fully agreed terms and conditions.',
      icon: Layers,
      iconColor: 'text-[#22C55E]',
      borderHighlight: 'hover:border-[#22C55E]',
      badge: 'Investment',
    },
    {
      title: 'Trading Mentorship',
      description: 'Personalized guidance, custom strategy development, and continuous ongoing mentorship.',
      icon: GraduationCap,
      iconColor: 'text-[#A855F7]',
      borderHighlight: 'hover:border-[#A855F7]',
      badge: 'Mentorship',
    },
  ];

  return (
    <section id="services" className="py-20 bg-[#061133] border-b border-[#1E3A8A]/40 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <span className="text-xs font-mono font-bold text-[#F59E0B] uppercase tracking-wider">
            INSTITUTIONAL SOLUTIONS
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white font-display tracking-tight">
            WHAT WE OFFER
          </h2>
          <p className="text-base text-slate-300 font-sans">
            Comprehensive market services structured to develop disciplined, profitable traders and investors.
          </p>
        </div>

        {/* 6 Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className={`p-6 rounded-2xl bg-[#0A1633] border border-[#1E3A8A] ${item.borderHighlight} transition-all duration-200 flex flex-col justify-between shadow-lg group`}
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="w-12 h-12 rounded-xl bg-[#070E22] border border-[#1E3A8A] flex items-center justify-center shrink-0">
                      <Icon className={`w-6 h-6 ${item.iconColor}`} />
                    </div>
                    <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-[#071330] text-slate-300 border border-[#1E3A8A]/60 uppercase tracking-wider">
                      {item.badge}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-white font-display group-hover:text-[#F59E0B] transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
                    {item.description}
                  </p>
                </div>

                <div className="pt-6 mt-4 border-t border-[#1E3A8A]/50">
                  <button
                    onClick={() => onSelectService(item.title)}
                    className="w-full py-2.5 rounded-xl bg-[#070E22] hover:bg-[#1E3A8A] border border-[#1E3A8A] text-xs font-bold text-slate-200 hover:text-white transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Inquire About {item.title}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Motto Bottom Strip */}
        <div className="mt-14 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0A1633] via-[#0D1D44] to-[#0A1633] border-2 border-[#F59E0B]/50 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
          <div className="space-y-1">
            <span className="text-xs font-mono font-bold text-[#F59E0B] uppercase tracking-wider">
              OUR GUIDING PRINCIPLE
            </span>
            <h4 className="text-2xl font-black text-white font-display">
              OUR MOTTO: TRADE TO WITHDRAW ALWAYS.
            </h4>
            <p className="text-xs sm:text-sm text-slate-300">
              Join The Patron Junior Forex Hub and take your trading journey to the next level.
            </p>
          </div>
          <button
            onClick={() => onSelectService('General Enrollment')}
            className="px-8 py-3.5 rounded-full bg-[#EA580C] hover:bg-[#C2410C] text-white font-black text-xs sm:text-sm uppercase tracking-wider transition-all shadow-lg shadow-[#EA580C]/25 whitespace-nowrap cursor-pointer shrink-0"
          >
            Join The Hub Today
          </button>
        </div>
      </div>
    </section>
  );
};
