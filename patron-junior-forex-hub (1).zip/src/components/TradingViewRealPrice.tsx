import React, { useEffect, useRef, useState } from 'react';
import { ExternalLink, TrendingUp, Sparkles } from 'lucide-react';

interface TradingViewRealPriceProps {
  pair: string;
  className?: string;
  onPriceDetected?: (price: number) => void;
}

// Map pair string to TradingView symbol identifier
export const getTradingViewSymbol = (pair: string): { symbol: string; title: string; defaultPrice: number } => {
  const normalized = pair.toUpperCase().replace(/\s+/g, '');
  if (normalized.includes('XAU') || normalized.includes('GOLD')) {
    return { symbol: 'FOREXCOM:XAUUSD', title: 'Gold vs US Dollar', defaultPrice: 4044.80 };
  }
  if (normalized.includes('NAS') || normalized.includes('100')) {
    return { symbol: 'FOREXCOM:NAS100', title: 'US Tech 100 Index', defaultPrice: 28541.50 };
  }
  if (normalized.includes('US30') || normalized.includes('DJI') || normalized.includes('DOW')) {
    return { symbol: 'FOREXCOM:DJI', title: 'Dow Jones 30', defaultPrice: 52948.00 };
  }
  if (normalized.includes('EUR')) {
    return { symbol: 'FX_IDC:EURUSD', title: 'Euro vs US Dollar', defaultPrice: 1.1259 };
  }
  if (normalized.includes('JPY')) {
    return { symbol: 'FX_IDC:USDJPY', title: 'US Dollar vs Japanese Yen', defaultPrice: 158.48 };
  }
  if (normalized.includes('GBP')) {
    return { symbol: 'FX_IDC:GBPUSD', title: 'British Pound vs US Dollar', defaultPrice: 1.3483 };
  }
  return { symbol: 'FOREXCOM:XAUUSD', title: 'Gold vs US Dollar', defaultPrice: 4044.80 };
};

export const TradingViewRealPrice: React.FC<TradingViewRealPriceProps> = ({ pair, className = '', onPriceDetected }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const { symbol, title, defaultPrice } = getTradingViewSymbol(pair);

  useEffect(() => {
    const currentContainer = containerRef.current;
    if (!currentContainer) return;

    // Reset container for new symbol
    currentContainer.innerHTML = '';
    setIsLoaded(false);

    const widgetDiv = document.createElement('div');
    widgetDiv.className = 'tradingview-widget-container__widget';
    currentContainer.appendChild(widgetDiv);

    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-single-quote.js';
    script.type = 'text/javascript';
    script.async = true;
    script.innerHTML = JSON.stringify({
      symbol: symbol,
      width: '100%',
      colorTheme: 'dark',
      isTransparent: true,
      locale: 'en',
    });

    script.onload = () => {
      setIsLoaded(true);
    };

    currentContainer.appendChild(script);

    if (onPriceDetected) {
      onPriceDetected(defaultPrice);
    }

    return () => {
      if (currentContainer) {
        currentContainer.innerHTML = '';
      }
    };
  }, [symbol, pair]);

  return (
    <div className={`relative bg-[#070E22] rounded-xl border border-[#1E3A8A] overflow-hidden p-3 ${className}`}>
      {/* Header bar indicating direct TradingView source */}
      <div className="flex items-center justify-between pb-2 mb-1 border-b border-[#1E3A8A]/50 text-xs">
        <div className="flex items-center gap-1.5 font-mono">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-[#FACC15] font-bold uppercase tracking-wider text-[11px]">
            TradingView Live Price Feed
          </span>
        </div>

        <a
          href={`https://www.tradingview.com/symbols/${symbol.replace(':', '-')}/`}
          target="_blank"
          rel="noreferrer"
          className="text-slate-400 hover:text-white flex items-center gap-1 text-[11px] transition-colors"
          title="Open chart on TradingView"
        >
          <span>{symbol}</span>
          <ExternalLink className="w-3 h-3 text-[#FACC15]" />
        </a>
      </div>

      {/* Embedded Live Widget from TradingView */}
      <div className="tradingview-widget-container min-h-[44px]" ref={containerRef}>
        <div className="tradingview-widget-container__widget"></div>
      </div>

      {/* Fallback display if widget takes time or if offline */}
      {!isLoaded && (
        <div className="flex items-center justify-between pt-1 text-xs font-mono text-slate-300">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">{pair}</span>
            <span className="text-emerald-400 font-extrabold text-sm sm:text-base">
              ${defaultPrice.toLocaleString()}
            </span>
          </div>
          <span className="text-[10px] text-slate-400 animate-pulse">Syncing TradingView...</span>
        </div>
      )}
    </div>
  );
};
