import React, { useState } from 'react';
import { Youtube, ExternalLink, Flame, Play, ShieldCheck, Award } from 'lucide-react';

import imgOfficialDesk from '../assets/story/WhatsApp_Image_2026-11-04_at_17.14.10__1__22db0f58.jpeg';
import imgDesk from '../assets/story/WhatsApp_Image_2026-11-04_at_17.14.31_18c94f9d.jpeg';
import imgHoodie from '../assets/story/WhatsApp_Image_2026-11-04_at_17.15.08_e1f59cdd.jpeg';
import imgMerch from '../assets/story/WhatsApp_Image_2026-11-04_at_17.15.15_87a2c9eb.jpeg';
import imgBroker from '../assets/story/WhatsApp_Image_2026-11-04_at_17.14.58_379e7928.jpeg';
import imgPortrait from '../assets/story/WhatsApp_Image_2026-11-04_at_17.15.03_86ec5d6e.jpeg';

export const OurStory: React.FC = () => {
  const storyImages = [
    {
      src: imgOfficialDesk,
      title: 'The Patron Capital Official Trading Desk',
      caption: 'Official workstation with illuminated "The Patron Capital" lightbox & multi-screen setup',
    },
    {
      src: imgDesk,
      title: 'Patron Junior at Live Trading Desk',
      caption: 'Analyzing Gold (XAUUSD) candlestick structure and liquidity flow',
    },
    {
      src: imgHoodie,
      title: 'Founder in Official White Hub Hoodie',
      caption: 'The Patron Junior Forex Hub branded hoodie & cap',
    },
    {
      src: imgMerch,
      title: 'Official Hub Merchandise',
      caption: 'Embroidered with "Trade to withdraw always"',
    },
    {
      src: imgBroker,
      title: 'Broker Partner & Trading Summit',
      caption: 'FBS Partner Summit - Deposit Into Your Future',
    },
    {
      src: imgPortrait,
      title: 'Patron Junior Studio Portrait',
      caption: 'Lead Fund Manager & Master Educator',
    },
  ];

  const [selectedImgIndex, setSelectedImgIndex] = useState(0);

  return (
    <section id="our-story" className="py-20 bg-[#030A20] border-b border-[#1E3A8A]/40 text-slate-100 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-[#1E3A8A]/15 blur-[130px] pointer-events-none rounded-full" />
      <div className="absolute bottom-10 right-10 w-[300px] h-[300px] bg-[#EA580C]/10 blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Overline & Title */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#0A1633] border border-[#F59E0B]/60 text-xs font-mono font-bold text-[#F59E0B] uppercase tracking-wider">
            <Flame className="w-4 h-4 text-[#EF4444]" />
            <span>MY STORY · FOUNDER & TRADING DESK</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white font-display tracking-tight">
            OUR STORY
          </h2>
          <p className="text-sm sm:text-base font-semibold text-[#F59E0B] font-mono tracking-wider uppercase">
            Our motto: Trade to Withdraw Always.
          </p>
        </div>

        {/* 2-Column Layout: Story Text & Image Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-16">
          {/* Left Column: Official Story Narrative */}
          <div className="lg:col-span-6 space-y-6">
            <div className="p-6 sm:p-8 rounded-3xl bg-[#0A1633] border-2 border-[#1E3A8A] shadow-xl space-y-5">
              <h3 className="text-2xl font-black text-white font-display">
                Building a Community of Confident, Disciplined Traders
              </h3>

              <p className="text-base sm:text-lg text-slate-200 leading-relaxed font-sans font-normal">
                The Patron Junior Forex Hub was founded with a vision of empowering traders through quality forex education, mentorship, and professional market analysis.
              </p>

              <p className="text-base text-slate-300 leading-relaxed font-sans">
                We focus on <strong className="text-white">Gold (XAUUSD)</strong>, <strong className="text-white">Smart Money Concepts</strong>, <strong className="text-white">Price Action</strong>, and <strong className="text-white">risk management</strong> to help traders make informed trading decisions.
              </p>

              <div className="p-4 rounded-2xl bg-[#071330] border border-[#F59E0B]/40 space-y-1">
                <span className="text-xs font-mono font-bold text-[#F59E0B] uppercase tracking-wider block">
                  The Core Goal
                </span>
                <p className="text-sm font-semibold text-white leading-relaxed">
                  Our goal is to build a community of knowledgeable, disciplined, and confident traders.
                </p>
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-[#1E3A8A]/60">
                <span className="text-xs font-mono font-black text-[#F59E0B] tracking-widest uppercase">
                  OUR MOTTO: TRADE TO WITHDRAW ALWAYS.
                </span>
                <div className="w-3 h-3 rounded-full bg-[#EF4444] animate-ping" />
              </div>
            </div>

            {/* YouTube Channel Spotlight Card */}
            <div className="p-6 rounded-3xl bg-gradient-to-r from-[#17060A] via-[#240A10] to-[#0A1633] border-2 border-[#EF4444]/60 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-[#EF4444] text-white flex items-center justify-center shrink-0 shadow-md">
                    <Youtube className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-white font-display">Official YouTube Channel</h4>
                    <span className="text-xs text-slate-400 font-mono">@THEPATRONJUNIOURFXHUB</span>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-md bg-[#EF4444]/20 border border-[#EF4444]/40 text-[#EF4444] text-[10px] font-mono font-bold uppercase">
                  Subscribe
                </span>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
                Watch weekly market breakdowns, Gold (XAUUSD) sniper breakdowns, and live price action analysis on our official channel.
              </p>

              <a
                href="https://www.youtube.com/@THEPATRONJUNIOURFXHUB"
                target="_blank"
                rel="noreferrer"
                className="w-full py-3 rounded-xl bg-[#EF4444] hover:bg-[#DC2626] text-white font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md shadow-[#EF4444]/30 cursor-pointer"
              >
                <Youtube className="w-4 h-4" />
                <span>Visit YouTube Channel (@THEPATRONJUNIOURFXHUB)</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Right Column: Real Photos of Patron Junior & Hub Merchandise */}
          <div className="lg:col-span-6 space-y-4">
            {/* Main Featured Photo Box */}
            <div className="relative rounded-3xl overflow-hidden border-2 border-[#1E3A8A] bg-[#0A1633] shadow-2xl group">
              <div className="relative aspect-[4/5] sm:aspect-[4/3] w-full overflow-hidden bg-black flex items-center justify-center">
                <img
                  src={storyImages[selectedImgIndex].src}
                  alt={storyImages[selectedImgIndex].title}
                  className="w-full h-full object-contain transition-transform duration-300 group-hover:scale-102"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A1633]/90 via-transparent to-transparent pointer-events-none" />

                {/* Photo Caption Overlay */}
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-2xl bg-[#070E22]/95 backdrop-blur-md border border-[#F59E0B]/60 flex items-center justify-between">
                  <div>
                    <h5 className="text-sm sm:text-base font-bold text-white font-display">
                      {storyImages[selectedImgIndex].title}
                    </h5>
                    <p className="text-xs text-[#F59E0B] font-mono mt-0.5">
                      {storyImages[selectedImgIndex].caption}
                    </p>
                  </div>
                  <div className="px-2.5 py-1 rounded bg-[#EA580C] text-white text-[10px] font-bold uppercase tracking-wider shrink-0 shadow-sm">
                    Verified
                  </div>
                </div>
              </div>
            </div>

            {/* Thumbnail Navigation Strip (6 Images) */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 pt-1">
              {storyImages.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImgIndex(idx)}
                  className={`relative aspect-square rounded-xl overflow-hidden border-2 transition-all cursor-pointer bg-black ${
                    selectedImgIndex === idx
                      ? 'border-[#F59E0B] ring-2 ring-[#F59E0B]/60 scale-105'
                      : 'border-[#1E3A8A]/60 opacity-60 hover:opacity-100 hover:border-slate-300'
                  }`}
                  title={img.title}
                >
                  <img
                    src={img.src}
                    alt={img.title}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
            <p className="text-[11px] text-center text-slate-300 font-mono">
              Click thumbnails above to view The Patron Capital official trading desk, founder at work, branded apparel, and summits.
            </p>
          </div>
        </div>

        {/* Embedded YouTube Video Container */}
        <div className="rounded-3xl overflow-hidden border-2 border-[#1E3A8A] bg-[#0A1633] p-6 sm:p-8 shadow-2xl">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-6 border-b border-[#1E3A8A]/60">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#EF4444] text-white flex items-center justify-center shrink-0 shadow-lg shadow-[#EF4444]/20">
                <Youtube className="w-7 h-7" />
              </div>
              <div>
                <span className="text-xs font-mono font-bold text-[#EF4444] uppercase tracking-wider">
                  YOUTUBE VIDEO & MASTERCLASSES
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-white font-display">
                  The Patron Junior Forex Hub Video Desk
                </h3>
              </div>
            </div>
            <a
              href="https://www.youtube.com/@THEPATRONJUNIOURFXHUB"
              target="_blank"
              rel="noreferrer"
              className="px-5 py-2.5 rounded-full bg-[#EF4444] hover:bg-[#DC2626] text-white font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all shadow-md shrink-0 cursor-pointer"
            >
              <span>Subscribe @THEPATRONJUNIOURFXHUB</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Video Player Showcase */}
          <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Interactive Player Frame featuring Official Trading Desk */}
            <div className="lg:col-span-8 relative aspect-video rounded-2xl overflow-hidden bg-black border border-[#1E3A8A] shadow-2xl flex items-center justify-center group">
              <img
                src={imgOfficialDesk}
                alt="The Patron Capital Official Trading Desk"
                className="w-full h-full object-cover opacity-75 group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none" />

              <a
                href="https://www.youtube.com/@THEPATRONJUNIOURFXHUB"
                target="_blank"
                rel="noreferrer"
                className="relative z-10 flex flex-col items-center gap-3 group-hover:scale-110 transition-transform cursor-pointer"
              >
                <div className="w-20 h-20 rounded-full bg-[#EF4444] text-white flex items-center justify-center shadow-2xl shadow-[#EF4444]/60">
                  <Play className="w-9 h-9 fill-white ml-1" />
                </div>
                <span className="text-sm font-bold text-white bg-black/80 px-4 py-1.5 rounded-full border border-white/20 backdrop-blur-md">
                  Click to Watch on YouTube (@THEPATRONJUNIOURFXHUB)
                </span>
              </a>

              <div className="absolute bottom-3 left-3 px-3 py-1 rounded bg-[#070E22]/95 border border-[#F59E0B] text-[10px] font-mono text-[#F59E0B] font-bold">
                THE PATRON CAPITAL · OFFICIAL TRADING DESK
              </div>
            </div>

            {/* Video Highlights */}
            <div className="lg:col-span-4 space-y-4">
              <div className="p-4 rounded-2xl bg-[#071330] border border-[#1E3A8A]/60 space-y-1">
                <span className="text-xs font-mono font-bold text-[#F59E0B]">01. Gold (XAUUSD) Strategy</span>
                <p className="text-xs text-slate-300">
                  Institutional order flow, liquidity grabs, and London/New York session sniper setups.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#071330] border border-[#1E3A8A]/60 space-y-1">
                <span className="text-xs font-mono font-bold text-[#38BDF8]">02. Smart Money Concepts</span>
                <p className="text-xs text-slate-300">
                  Fair value gaps, order blocks, and supply & demand imbalance identification.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#071330] border border-[#1E3A8A]/60 space-y-1">
                <span className="text-xs font-mono font-bold text-[#22C55E]">03. Trade to Withdraw</span>
                <p className="text-xs text-slate-300">
                  Risk mitigation, lot sizing discipline, and prop firm passing rules.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
