import React, { useState } from 'react';
import { Calculator, ShieldCheck, AlertTriangle, Percent, DollarSign } from 'lucide-react';

export const ForexCalculators: React.FC = () => {
  const [balance, setBalance] = useState<number>(10000);
  const [riskMode, setRiskMode] = useState<'percent' | 'dollar'>('percent');
  const [riskPercent, setRiskPercent] = useState<number>(1.5);
  const [riskDollarInput, setRiskDollarInput] = useState<number>(150);
  const [stopLossPips, setStopLossPips] = useState<number>(30);
  const [pair, setPair] = useState<string>('XAU/USD');

  // Pip value multiplier per standard lot (1.0 lot)
  // XAU/USD: $10 per pip (0.10 move = $10 per lot)
  // NAS100: $1 per point/pip
  // US30: $1 per point/pip
  // EUR/USD, GBP/USD, USD/JPY: standard $10 per pip
  const pipValue = pair === 'XAU/USD' ? 10 : (pair === 'NAS100' || pair === 'US30') ? 1 : 10;

  // Calculate risk amount in dollars based on mode
  const riskAmount = riskMode === 'percent'
    ? balance * (Math.max(0, riskPercent) / 100)
    : Math.max(0, riskDollarInput);

  // Sync the opposite value
  const effectiveRiskPercent = balance > 0 ? (riskAmount / balance) * 100 : 0;

  const handlePercentChange = (val: number) => {
    setRiskPercent(val);
    setRiskDollarInput(Number((balance * (val / 100)).toFixed(2)));
  };

  const handleDollarChange = (val: number) => {
    setRiskDollarInput(val);
    if (balance > 0) {
      setRiskPercent(Number(((val / balance) * 100).toFixed(2)));
    }
  };

  const handleBalanceChange = (newBalance: number) => {
    setBalance(newBalance);
    if (riskMode === 'percent') {
      setRiskDollarInput(Number((newBalance * (riskPercent / 100)).toFixed(2)));
    } else if (newBalance > 0) {
      setRiskPercent(Number(((riskDollarInput / newBalance) * 100).toFixed(2)));
    }
  };

  const rawLot = stopLossPips > 0 ? riskAmount / (stopLossPips * pipValue) : 0;
  const calculatedLot = Math.max(0.01, Number(rawLot.toFixed(2)));
  const rewardAt3 = riskAmount * 3;
  const isHighRisk = effectiveRiskPercent > 3.0;
  const isCautionRisk = effectiveRiskPercent > 2.0 && effectiveRiskPercent <= 3.0;

  return (
    <section id="calculator" className="py-16 bg-[#070E22] border-b border-[#1E3A8A]/40 text-slate-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center space-y-2 mb-10">
          <span className="text-xs font-mono font-bold text-[#FACC15] uppercase tracking-wider">
            Risk Management Tool
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
            Position Size & Lot Calculator
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            Never risk blindly. Enter your exact custom risk parameter to calculate the institutional lot size before entering any trade.
          </p>
        </div>

        {/* Clean 2-Column Calculator Box */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-[#0A1633] border-2 border-[#1E3A8A] rounded-2xl p-6 sm:p-8 shadow-xl">
          {/* Left Column: User Inputs */}
          <div className="space-y-4">
            {/* Instrument Selection */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Instrument
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                {['XAU/USD', 'NAS100', 'US30', 'EUR/USD', 'GBP/USD', 'USD/JPY'].map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPair(p)}
                    className={`py-2 px-1 text-[11px] font-mono font-bold rounded-lg border transition-all cursor-pointer ${
                      pair === p
                        ? 'bg-[#1E3A8A] border-[#FACC15] text-[#FACC15] shadow-xs'
                        : 'bg-[#070E22] border-[#1E3A8A]/50 text-slate-300 hover:text-white'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Account Balance */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Account Balance ($)
                </label>
                <span className="text-[11px] text-slate-400 font-mono">
                  Equity: ${balance.toLocaleString()}
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm">$</span>
                <input
                  type="number"
                  min="1"
                  step="100"
                  value={balance || ''}
                  onChange={(e) => handleBalanceChange(Math.max(0, Number(e.target.value)))}
                  className="w-full bg-[#070E22] border border-[#1E3A8A] rounded-xl pl-8 pr-3.5 py-2.5 text-sm font-mono text-white focus:outline-none focus:border-[#FACC15]"
                  placeholder="Enter your balance"
                />
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {[1000, 5000, 10000, 25000, 50000, 100000].map((b) => (
                  <button
                    key={b}
                    type="button"
                    onClick={() => handleBalanceChange(b)}
                    className={`px-2.5 py-1 text-[10px] font-mono rounded border transition-colors cursor-pointer ${
                      balance === b
                        ? 'bg-[#1E3A8A] border-[#FACC15] text-white font-bold'
                        : 'bg-[#070E22] border-[#1E3A8A]/50 text-slate-300 hover:bg-[#1E3A8A]/40'
                    }`}
                  >
                    ${b >= 1000 ? `${b / 1000}k` : b}
                  </button>
                ))}
              </div>
            </div>

            {/* Risk Per Trade (Custom User Input Field + Mode Switch) */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Risk Per Trade
                </label>
                {/* Mode Switch: % or $ */}
                <div className="flex items-center p-0.5 bg-[#070E22] border border-[#1E3A8A] rounded-lg text-[10px] font-mono">
                  <button
                    type="button"
                    onClick={() => setRiskMode('percent')}
                    className={`px-2 py-0.5 rounded font-bold cursor-pointer transition-colors ${
                      riskMode === 'percent'
                        ? 'bg-[#FACC15] text-slate-950 shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    % Percent
                  </button>
                  <button
                    type="button"
                    onClick={() => setRiskMode('dollar')}
                    className={`px-2 py-0.5 rounded font-bold cursor-pointer transition-colors ${
                      riskMode === 'dollar'
                        ? 'bg-[#FACC15] text-slate-950 shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    $ Amount
                  </button>
                </div>
              </div>

              {/* Direct Customizable Input Field where user can feed his/her own risk */}
              {riskMode === 'percent' ? (
                <div className="relative">
                  <input
                    type="number"
                    min="0.1"
                    max="100"
                    step="0.1"
                    value={riskPercent === 0 ? '' : riskPercent}
                    onChange={(e) => handlePercentChange(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#070E22] border-2 border-[#1E3A8A] focus:border-[#FACC15] rounded-xl pl-3.5 pr-20 py-2.5 text-sm font-mono text-white focus:outline-none transition-all"
                    placeholder="Feed your risk % (e.g. 1.25)"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 pointer-events-none">
                    <span className="text-xs font-bold text-[#FACC15] font-mono">% Risk</span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      (${riskAmount.toFixed(0)})
                    </span>
                  </div>
                </div>
              ) : (
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm">$</span>
                  <input
                    type="number"
                    min="1"
                    step="10"
                    value={riskDollarInput === 0 ? '' : riskDollarInput}
                    onChange={(e) => handleDollarChange(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#070E22] border-2 border-[#1E3A8A] focus:border-[#FACC15] rounded-xl pl-8 pr-24 py-2.5 text-sm font-mono text-white focus:outline-none transition-all"
                    placeholder="Feed your dollar risk (e.g. 150)"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 pointer-events-none">
                    <span className="text-xs font-bold text-[#FACC15] font-mono">
                      ({effectiveRiskPercent.toFixed(1)}%)
                    </span>
                  </div>
                </div>
              )}

              {/* Quick Preset Buttons for easy 1-click feeding or custom reference */}
              <div className="grid grid-cols-4 sm:grid-cols-5 gap-1.5 mt-2">
                {[0.5, 1.0, 1.5, 2.0, 3.0].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => {
                      setRiskMode('percent');
                      handlePercentChange(r);
                    }}
                    className={`py-1.5 text-xs font-mono font-bold rounded-lg border transition-all cursor-pointer ${
                      riskMode === 'percent' && riskPercent === r
                        ? 'bg-[#1E3A8A] border-[#FACC15] text-[#FACC15] shadow-xs'
                        : 'bg-[#070E22] border-[#1E3A8A]/50 text-slate-300 hover:bg-[#0C1A3D]'
                    }`}
                  >
                    {r}%
                  </button>
                ))}
              </div>
            </div>

            {/* Stop Loss Pips */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Stop Loss (Pips / Points)
                </label>
                <span className="text-[11px] text-slate-400 font-mono">
                  {pair === 'XAU/USD' ? '1 pip = 0.10 Gold move' : 'Points to Invalidation'}
                </span>
              </div>
              <input
                type="number"
                min="1"
                step="1"
                value={stopLossPips || ''}
                onChange={(e) => setStopLossPips(Math.max(1, Number(e.target.value) || 1))}
                className="w-full bg-[#070E22] border border-[#1E3A8A] rounded-xl px-3.5 py-2.5 text-sm font-mono text-white focus:outline-none focus:border-[#FACC15]"
                placeholder="Enter SL pips"
              />
              <div className="flex gap-1.5 mt-2">
                {[10, 20, 30, 50, 100].map((sl) => (
                  <button
                    key={sl}
                    type="button"
                    onClick={() => setStopLossPips(sl)}
                    className={`px-2.5 py-1 text-[10px] font-mono rounded border transition-colors cursor-pointer ${
                      stopLossPips === sl
                        ? 'bg-[#1E3A8A] border-[#FACC15] text-white font-bold'
                        : 'bg-[#070E22] border-[#1E3A8A]/50 text-slate-300 hover:bg-[#1E3A8A]/40'
                    }`}
                  >
                    {sl} pips
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Dynamic Real-Time Results */}
          <div className="bg-[#070E22] border border-[#1E3A8A] rounded-xl p-6 flex flex-col justify-between space-y-5">
            <div className="text-center space-y-1">
              <span className="text-[11px] uppercase tracking-wider text-slate-400 font-mono">
                Calculated Lot Size
              </span>
              <div className="text-4xl sm:text-5xl font-black text-[#FACC15] font-mono tabular-nums tracking-tight">
                {calculatedLot} <span className="text-sm font-sans text-slate-300 font-normal">Lots</span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono block">
                {pair} · {stopLossPips} Pips SL · {effectiveRiskPercent.toFixed(1)}% Risk
              </span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="flex justify-between items-center p-2.5 rounded-lg bg-[#0A1633] border border-[#EF4444]/40">
                <span className="text-slate-300 font-sans">Max Dollar Loss:</span>
                <strong className="text-[#EF4444] text-sm">-${riskAmount.toFixed(2)}</strong>
              </div>
              <div className="flex justify-between items-center p-2.5 rounded-lg bg-[#0A1633] border border-emerald-500/40">
                <span className="text-slate-300 font-sans">Target Gain (1:3 R:R):</span>
                <strong className="text-emerald-400 text-sm">+${rewardAt3.toFixed(2)}</strong>
              </div>
              <div className="flex justify-between items-center p-2 rounded-lg bg-[#0A1633]/60 border border-[#1E3A8A]/30 text-[11px]">
                <span className="text-slate-400 font-sans">Effective Risk Ratio:</span>
                <span className="text-slate-200 font-bold">
                  {effectiveRiskPercent.toFixed(2)}% of ${balance.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Dynamic Risk Guidance based on user input */}
            {isHighRisk ? (
              <div className="p-3 bg-red-950/70 rounded-lg border border-[#EF4444]/60 flex items-start gap-2.5 text-xs text-red-200">
                <AlertTriangle className="w-4 h-4 text-[#EF4444] shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-[#EF4444] font-bold">High Risk Alert ({effectiveRiskPercent.toFixed(1)}%)</strong>
                  <span>Risking over 3% per trade creates aggressive drawdown risk. Trade to withdraw always!</span>
                </div>
              </div>
            ) : isCautionRisk ? (
              <div className="p-3 bg-amber-950/60 rounded-lg border border-amber-500/50 flex items-start gap-2.5 text-xs text-amber-200">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-amber-300 font-bold">Moderate Risk ({effectiveRiskPercent.toFixed(1)}%)</strong>
                  <span>Ensure your edge and stop loss alignment before entering.</span>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-[#13234F] rounded-lg border border-[#1E3A8A] flex items-center gap-2.5 text-xs text-slate-200">
                <ShieldCheck className="w-4 h-4 text-[#FACC15] shrink-0" />
                <span>
                  <strong>Patron Rule:</strong> Ideal risk is 1% – 2%. Protect capital to withdraw always!
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
