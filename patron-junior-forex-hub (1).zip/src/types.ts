export interface CurrencyQuote {
  symbol: string;
  name: string;
  bid: number;
  ask: number;
  change: number;
  changePips: number;
  high: number;
  low: number;
  spread: number;
  category: 'forex' | 'indices' | 'commodities' | 'crypto';
}

export interface TradeSignal {
  id: string;
  pair: string;
  type: 'BUY' | 'SELL' | 'BUY LIMIT' | 'SELL LIMIT';
  entry: number;
  stopLoss: number;
  tp1: number;
  tp2: number;
  tp3: number;
  status: 'ACTIVE' | 'TP1 HIT' | 'TP2 HIT' | 'TP3 SMASHED' | 'CLOSED';
  pipsGained: number;
  riskReward: string;
  timeframe: string;
  date: string;
  setupRationale: string;
  category: 'gold' | 'indices' | 'fx';
}

export interface MentorshipTier {
  id: string;
  name: string;
  badge: string;
  price: string;
  billingPeriod: string;
  description: string;
  popular?: boolean;
  features: string[];
  ctaText: string;
  telegramLink?: string;
}

export interface StudentProof {
  id: string;
  name: string;
  location: string;
  payoutAmount: string;
  propFirm: string;
  accountSize: string;
  quote: string;
  date: string;
  verifiedBadge: string;
}

export interface EconomicEvent {
  id: string;
  time: string;
  currency: string;
  event: string;
  impact: 'HIGH' | 'MEDIUM' | 'LOW';
  forecast: string;
  previous: string;
}
