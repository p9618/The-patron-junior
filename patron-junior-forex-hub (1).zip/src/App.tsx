import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { TickerBar } from './components/TickerBar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { OurStory } from './components/OurStory';
import { WhatWeOffer } from './components/WhatWeOffer';
import { SignalTerminal } from './components/SignalTerminal';
import { ForexCalculators } from './components/ForexCalculators';
import { MentorshipPlans } from './components/MentorshipPlans';
import { ProofWall } from './components/ProofWall';
import { Footer } from './components/Footer';
import { ContactWidget } from './components/ContactWidget';
import { AppointmentModal } from './components/AppointmentModal';
import { EnrollmentModal } from './components/EnrollmentModal';

export default function App() {
  const [isAppointmentOpen, setIsAppointmentOpen] = useState(false);
  const [enrollModal, setEnrollModal] = useState<{ isOpen: boolean; tierId: string }>({
    isOpen: false,
    tierId: 'vip-signals',
  });

  const handleOpenEnrollModal = (tierId: string = 'vip-signals') => {
    setEnrollModal({ isOpen: true, tierId });
  };

  const handleCloseEnrollModal = () => {
    setEnrollModal((prev) => ({ ...prev, isOpen: false }));
  };

  const handleSelectService = (serviceName: string) => {
    setIsAppointmentOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#040D27] text-slate-100 flex flex-col font-sans selection:bg-[#F97316] selection:text-white">
      {/* 1. Header with Top Announcement Bar & White Navigation Bar (Screenshot 1) */}
      <Navbar
        onOpenAppointment={() => setIsAppointmentOpen(true)}
        onOpenContact={() => setIsAppointmentOpen(true)}
      />

      {/* 2. Clean White TradingView Ticker Tape (Screenshot 1) */}
      <TickerBar />

      {/* 3. Hero Section (Screenshot 1 & 2) */}
      <main className="flex-1">
        <Hero onOpenContact={() => setIsAppointmentOpen(true)} />

        {/* 4. Official About Us, Mission, Vision & Why Choose Us Section */}
        <AboutSection />

        {/* 5. OUR STORY (Under Our Motto with real pictures & YouTube video) */}
        <OurStory />

        {/* 6. Official WHAT WE OFFER Section (6 Pillars) */}
        <WhatWeOffer onSelectService={handleSelectService} />

        {/* 7. Live Signals (Signals Feed & Execution) */}
        <div id="signals">
          <SignalTerminal onJoinVIP={() => handleOpenEnrollModal('vip-signals')} />
        </div>

        {/* 8. Lot Size & Risk Calculator */}
        <div id="calculator">
          <ForexCalculators />
        </div>

        {/* 9. Mentorship & VIP Membership Plans */}
        <div id="mentorship">
          <MentorshipPlans onSelectTier={handleOpenEnrollModal} />
        </div>

        {/* 10. Verified Student Payout Proofs */}
        <div id="payouts">
          <ProofWall />
        </div>
      </main>

      {/* 11. Footer with Official Disclaimer */}
      <Footer onOpenEnrollModal={() => setIsAppointmentOpen(true)} />

      {/* Floating "Contact us" widget in bottom-left corner (Screenshot 1 & 2) */}
      <ContactWidget onClick={() => setIsAppointmentOpen(true)} />

      {/* Appointment / Contact Modal */}
      <AppointmentModal
        isOpen={isAppointmentOpen}
        onClose={() => setIsAppointmentOpen(false)}
      />

      {/* Enrollment Modal */}
      <EnrollmentModal
        isOpen={enrollModal.isOpen}
        tierId={enrollModal.tierId}
        onClose={handleCloseEnrollModal}
      />
    </div>
  );
}
